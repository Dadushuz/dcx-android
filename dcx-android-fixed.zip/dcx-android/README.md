# АРМ ДЦХ — Чиланзарская линия (native Android)

Rus tilidagi native Android ilova: **Kotlin + Jetpack Compose, arxitektura MVVM, lokal baza Room, backend Firebase (Auth + Realtime Database)**. Bu WebView yoki sayt emas — to'liq native Kotlin kodi.

> Metro DЦХ navbatchilik buyruqlarini boshqarish: buyruq yaratish (7 tur), tasdiqlash, jurnal, shablonlar, hisobotlar (CSV), loglar/audit, rollar.

---

## 1. Nima bor (funksiyalar)

| Bo'lim | Tavsif |
|---|---|
| **Kirish (login)** | Firebase Auth (email + parol). Seans DataStore'da saqlanadi — smena ichida parol qayta so'ralmaydi. Xato holatlari rus tilida aniq ko'rsatiladi. |
| **Navbatchilik** | Navbatchilikni qabul qilish va topshirish (eski/yangi DЦХ F.I.Sh.), smena oynasi (08:00/20:00), joriy navbatchi va keyingi buyruq raqami. |
| **Buyruq yaratish** | 7 tur: xo'jalik poyezdi (noto'g'ri yo'nalish), AB → ALS-ARS, ALS-ARS → AB, energodispetcherga (ЭЧЦ), kuchlanishni uzish, yo'lni yopish, navbatchilikni qabul qilish. Avtomatik raqamlash, shablon matnlari, stamp prender ko'rinishi. |
| **Xavfli amallar** | Kuchlanishni uzish va yo'lni yopish uchun **ikki bosqichli tasdiqlash** — "Я осознаю последствия" checkbox bosilmaguncha tasdiq tugmasi bloklanadi. |
| **Validatsiya** | Bo'sh maydonlar, vaqt formati (ЧЧ:ММ), poyezd raqami (3–6 raqam), stansiya tanlovi, bir xil stansiya, vaqt xronologiyasi. Xato maydonlari qizil belgilanadi. |
| **Jurnal** | 4 ko'rinish: Barchasi / Tasdiqda / Jurnalga kiritilmagan / Qoralamalar. Tasdiqlash (katta DЦХ), jurnalga kiritish, sabab ko'rsatib bekor qilish. |
| **Holatlar** | `ЧЕРНОВИК → НА УТВЕРЖДЕНИИ → ВЫДАН → ВНЕСЁН В ЖУРНАЛ` (+ `ОТМЕНЁН`) — har bir kartada rangli belgi bilan. |
| **Shablonlar** | Bo'limlar bo'yicha matn shablonlari, `{путь}`, `{участок}`, `{доп}` o'rinbosarlari. |
| **Hisobotlar** | Smena / stansiya / buyruq turi / xodim / sana oralig'i bo'yicha filtr, 5 ta xulosa ko'rsatkichi va **CSV eksport** (Excel uchun BOM + `;` ajratgich). |
| **Loglar / audit** | Oxirgi 300 amal: kim, qachon, nima qildi. |
| **Rollar** | Работник станции (faqat ko'rish/qabul), ДЦХ (buyruq berish), Старший ДЦХ (tasdiqlash), Основатель (hisoblar, raqamlash, tozalash, arxiv). |
| **Offline-first** | Har bir o'zgarish avval Room'ga yoziladi, keyin Firebase'ga yuboriladi. Aloqa yo'q bo'lsa — navbatda saqlanadi va `WorkManager` orqali ulanish tiklanganda yuboriladi. |

---

## 2. Loyiha tuzilmasi

```
dcx-android/
├── settings.gradle.kts              # modullar va repozitoriylar
├── build.gradle.kts                 # ildiz skript (plug-in'lar)
├── gradle.properties                # JVM/AndroidX sozlamalari
├── gradle/
│   ├── libs.versions.toml           # versiyalar katalogi (barcha kutubxonalar)
│   └── wrapper/gradle-wrapper.properties
├── gradlew / gradlew.bat            # Gradle wrapper skriptlari
├── .github/workflows/android.yml    # CI: push'da debug APK yig'adi
└── app/
    ├── build.gradle.kts             # app moduli (SDK, Compose, Room, Firebase)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/                     # strings.xml (rus), themes, colors, icons, xml rules
        └── java/uz/metro/chilonzor/dcxduty/
            ├── DcxApp.kt            # Application: DI, seansni tiklash, sync ishga tushirish
            ├── MainActivity.kt      # single-activity + Compose
            ├── di/AppContainer.kt   # qo'lda DI (Hilt'siz)
            ├── domain/
            │   ├── model/           # Role, OrderStatus, OrderCategory, Station, Order, …
            │   ├── repository/      # repozitoriy interfeyslari
            │   └── usecase/         # validatsiya, matn yig'ish, CSV eksport, smena oynasi
            ├── data/
            │   ├── local/           # Room: entity, DAO, database, converters, DataStore
            │   ├── remote/          # Firebase Auth + RTDB (SDK va REST), NetworkMonitor
            │   └── repository/      # offline-first implementatsiyalar
            ├── sync/SyncWorker.kt   # WorkManager davriy sinxronizatsiya
            └── ui/
                ├── theme/           # Material3 ranglar, tipografiya, shakllar
                ├── components/      # StatusChip, DangerConfirmDialog, SectionCard, …
                ├── navigation/      # marshrutlar, bottom-tab konfiguratsiyasi
                ├── screens/         # Login, Duty, CreateOrder, Journal, Reports, Templates, Logs, Admin
                └── viewmodel/       # Login, AppShell, Duty, CreateOrder, Journal, Reports, …
```

---

## 3. Gradle va texnologiyalar

- **AGP 8.7.3**, **Kotlin 2.0.21**, **KSP 2.0.21-1.0.28**, Gradle 8.9
- `compileSdk = 35`, `minSdk = 24`, `targetSdk = 35`, JVM target 17
- Compose BOM `2024.09.03`, Material3, Material Icons Extended
- Navigation Compose `2.8.4`, Lifecycle `2.8.7` (ViewModel + `collectAsStateWithLifecycle`)
- Room `2.6.1` (KSP orqali), WorkManager `2.9.1`, DataStore Preferences `1.1.1`
- Firebase BoM `33.5.1` (Auth, Realtime Database, Analytics), Coroutines `1.8.1`, Gson `2.11.0`

---

## 4. GitHub Codespaces'da ochish (bepul)

1. Repozitoriyni GitHub'ga yuklang (**kod `dcx-android/` papkasi ichida**).
2. Repo sahifasida **Code → Codespaces → Create codespace on main** ni bosing.
3. Codespace ochilgach, terminalda:

```bash
# Agar kod ichki papkada bo'lsa
cd dcx-android

# Gradle wrapper'ga ruxsat
chmod +x ./gradlew

# Debug APK yig'ish
./gradlew assembleDebug
```

4. APK manzili: `app/build/outputs/apk/debug/app-debug.apk`

> **Muhim:** Codespaces bepul tarifida Android SDK odatda o'rnatilmagan bo'lishi mumkin. Har holda **GitHub Actions** (5-bo'lim) APK'ni avtomatik yig'adi — bu eng ishonchli va bepul usul. Codespaces'da faqat kodni tahrirlash qulay.

---

## 5. Firebase'ni ulash (`google-services.json`) — 3-qadam

> Ilova `google-services.json` **bo'lmasa ham** ishga tushadi: u holda Firebase **REST-rejimida** (email/parol orqali kirish + RTDB'ga HTTPS so'rovlar) ishlaydi. To'liq SDK rejimi uchun quyidagini bajaring.

1. **Firebase Console** → loyihangiz (`chilonzor-ikr`, RTDB: `chilonzor-ikr-default-rtdb`) → ⚙️ **Project settings** → **Your apps** → **Add app** → **Android**.
2. **Android package name** maydoniga aynan yozing:
   ```
   uz.metro.chilonzor.dcxduty
   ```
   (debug uchun: `uz.metro.chilonzor.dcxduty.debug` — agar debug APK'ga alohida ro'yxatdan o'tkazmoqchi bo'lsangiz, uni ham qo'shing.)
3. **Download google-services.json** → faylni loyihadagi `app/` papkasiga joylashtiring:
   ```
   dcx-android/app/google-services.json
   ```
4. Gradle avtomatik aniqlaydi: fayl bo'lsa `google-services` plug-in'i ulanadi, bo'lmasa REST-rejim ishlaydi (build xato bermaydi).

### Firebase Console'da qo'lda sozlash
- **Authentication → Sign-in method → Email/Password** ni yoqing.
- **Realtime Database** → ma'lumotlar `dcx_v8/` ildizida saqlanadi (`orders`, `meta`, `logs`, `templates`, `users`).
- **Database → Rules** (boshlang'ich, faqat autentifikatsiya qilinganlarga ruxsat):

```json
{
  "rules": {
    "dcx_v8": {
      ".read": "auth != null",
      ".write": "auth != null"
    }
  }
}
```

- Birinchi **Основатель** akkauntini Firebase Console → Authentication → **Add user** orqali yarating, so'ng RTDB'da uning profilini yozing:

```json
{
  "dcx_v8": {
    "users": {
      "<UID>": {
        "uid": "<UID>",
        "email": "founder@chilonzor.uz",
        "name": "Иванов И.",
        "role": "founder",
        "active": true
      }
    }
  }
}
```

Qolgan hisoblarni ilovaning **«Панель основателя»** bo'limidan yarating (rol va stansiya tanlash bilan).

### Xavfsizlik bo'yicha eslatma
- `FirebaseConfig.kt` dagi API kalit **klient kaliti** (maxfiy emas), lekin uni **Google Cloud Console → Credentials** bo'limida Android ilova + SHA-1 va HTTP-referrer bo'yicha cheklang.
- **Firebase App Check** ni yoqing (Play Integrity) — bu RTDB'ga ruxsatsiz yozishni to'sadi.
- RTDB Rules'ni ishlab chiqarishga chiqarishdan oldin rollar bo'yicha qattiqlashtiring (`auth.token` custom claims).

---

## 6. GitHub Actions orqali APK yig'ish (bepul)

Workflow: `.github/workflows/android.yml`

1. Kodni GitHub'ga `push` qiling (`main` yoki `master` branch).
2. Repo → **Actions** bo'limiga o'ting → **«Android CI — сборка debug APK»** ishga tushadi.
3. Ish tugagach, sahifa pastidagi **Artifacts** bo'limidan **`dcxduty-debug-apk`** ni yuklab oling.
4. Ichida: `app-debug.apk`.

Qo'lda ishga tushirish: **Actions → Android CI → Run workflow**.

> Agar `app/google-services.json` bo'lmasa, CI ogohlantirish chiqaradi va APK **REST-rejimida** yig'iladi — build baribir muvaffaqiyatli tugaydi.

---

## 7. APK'ni telefonga o'rnatish

1. Yuklab olingan `app-debug.apk` ni telefonga o'tkazing (USB, Telegram, Google Drive).
2. Telefonda **Sozlamalar → Xavfsizlik → Noma'lum manbalardan o'rnatishga ruxsat** ni yoqing (Android 8+ da ilova bo'yicha so'raladi).
3. Faylni ochib **«O'rnatish»** ni bosing.
4. Ilova nomi: **АРМ ДЦХ — Чиланзарская линия**.

> Debug APK `uz.metro.chilonzor.dcxduty.debug` paket nomi bilan o'rnatiladi — bu bir telefonda ham release, ham debug versiyani yonma-yon saqlash imkonini beradi.

---

## 8. Keyingi qadamlar (tavsiya)

1. **Firebase loyihasini ulash** — `google-services.json` qo'shish + RTDB Rules.
2. **Birinchi akkauntlar** — Основатель, keyin ДЦХ va Станший ДЦХ, stansiya xodimlari.
3. **Real qurilmada sinov** — login, buyruq yaratish (ayniqsa xavfli amallar), oflayn rejim, CSV eksport.
4. **UI sayqallash** — ekranlarni real ish jarayoniga moslash (masalan, stansiyaga qarab buyruq filtri).
5. **Release imzosi** — kalit generatsiya qilib, `signingConfigs` qo'shish va `assembleRelease` ni CI'ga ulash.

---

## Litsenziya / egalik

Ichki korporativ loyiha (Chilonzar liniyasi DЦХ). Tarqatish tartibi tashkilot ichida belgilanadi.
