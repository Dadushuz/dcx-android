# ===== Firebase =====
-keepattributes Signature
-keepattributes *Annotation*
-keepclassmembers class uz.metro.chilonzor.dcxduty.data.remote.dto.** {
    *;
}
# Gson-модели сохраняются целиком
-keep class uz.metro.chilonzor.dcxduty.data.remote.dto.** { *; }

# ===== Room =====
-keep class * extends androidx.room.RoomDatabase { *; }

# ===== Общие правила Kotlin =====
-dontwarn kotlinx.coroutines.**
-keep class kotlin.Metadata { *; }
