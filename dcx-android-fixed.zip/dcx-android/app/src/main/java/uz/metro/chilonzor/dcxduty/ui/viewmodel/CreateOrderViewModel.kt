package uz.metro.chilonzor.dcxduty.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import uz.metro.chilonzor.dcxduty.data.repository.AuthRepositoryImpl
import uz.metro.chilonzor.dcxduty.domain.model.FieldKeys
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.OrderCategory
import uz.metro.chilonzor.dcxduty.domain.model.OrderTemplate
import uz.metro.chilonzor.dcxduty.domain.model.Shift
import uz.metro.chilonzor.dcxduty.domain.model.ValidationResult
import uz.metro.chilonzor.dcxduty.domain.repository.OrderRepository
import uz.metro.chilonzor.dcxduty.domain.repository.TemplateRepository
import uz.metro.chilonzor.dcxduty.domain.usecase.ComposeOrderTextUseCase
import uz.metro.chilonzor.dcxduty.domain.usecase.ShiftWindowUseCase
import uz.metro.chilonzor.dcxduty.domain.usecase.ValidateOrderUseCase
import java.util.UUID

/** Состояние формы создания приказа. */
data class CreateOrderUiState(
    val category: OrderCategory = OrderCategory.HOZ_WRONG_DIR,
    val fields: Map<String, String> = emptyMap(),
    val errors: Map<String, String> = emptyMap(),
    val allStations: Boolean = false,
    val targetStations: Set<String> = emptySet(),
    val bodyPreview: String = "",
    val subTemplates: List<OrderTemplate> = emptyList(),
    val selectedSubTemplateId: String? = null,
    val requireApproval: Boolean = true,
    val showDangerDialog: Boolean = false,
    val saving: Boolean = false,
    val userRoleCanIssue: Boolean = false,
    val nextNumber: Int = 1,
    val shiftWindowOpen: Boolean = false,
    val nowTimeText: String = "",
)

class CreateOrderViewModel(
    private val orderRepo: OrderRepository,
    private val templateRepo: TemplateRepository,
    private val auth: AuthRepositoryImpl,
    private val shiftWindow: ShiftWindowUseCase,
) : ViewModel() {

    private val validator = ValidateOrderUseCase()
    private val composer = ComposeOrderTextUseCase()

    private val _state = MutableStateFlow(CreateOrderUiState())
    private val _toast = MutableStateFlow<Pair<String, Boolean>?>(null)

    /** Состояние формы приказа (читается экраном через vm.state). */
    val state: StateFlow<CreateOrderUiState> = _state.asStateFlow()
    val toast: StateFlow<Pair<String, Boolean>?> = _toast.asStateFlow()

    init {
        viewModelScope.launch {
            templateRepo.observeAll().collect { templates ->
                _state.update { it.copy(subTemplates = templates.filter { t -> t.category == it.category }) }
            }
        }
        viewModelScope.launch {
            orderRepo.observePendingCount()
            refreshMeta()
        }
        viewModelScope.launch {
            auth.currentUser.collect { user ->
                _state.update { it.copy(userRoleCanIssue = user?.role?.canIssue == true) }
            }
        }
    }

    private suspend fun refreshMeta() {
        val next = orderRepo.peekNextNumber()
        _state.update {
            it.copy(
                nextNumber = next,
                shiftWindowOpen = shiftWindow(),
                nowTimeText = shiftWindow.time(),
                fields = it.fields + (FieldKeys.TIME to (it.fields[FieldKeys.TIME]?.takeIf { v -> v.isNotBlank() }
                    ?: shiftWindow.time())),
            )
        }
        syncSubTemplates()
    }

    fun selectCategory(category: OrderCategory) {
        _state.update {
            it.copy(
                category = category,
                errors = emptyMap(),
                selectedSubTemplateId = null,
                bodyPreview = "",
            )
        }
        syncSubTemplates()
    }

    fun selectSubTemplate(id: String?) {
        _state.update { it.copy(selectedSubTemplateId = id) }
        rebuildPreview()
    }

    private fun syncSubTemplates() {
        val cat = _state.value.category
        _state.update { st ->
            st.copy(subTemplates = st.subTemplates.filter { it.category == cat })
        }
        rebuildPreview()
    }

    fun onField(key: String, value: String) {
        _state.update { st ->
            st.copy(
                fields = st.fields + (key to value),
                errors = if (st.errors.containsKey(key)) st.errors - key else st.errors,
            )
        }
        rebuildPreview()
    }

    fun toggleAllStations(value: Boolean) = _state.update { it.copy(allStations = value, errors = emptyMap()) }

    fun toggleTargetStation(code: String) = _state.update { st ->
        val set = st.targetStations.toMutableSet()
        if (!set.add(code)) set.remove(code)
        st.copy(targetStations = set)
    }

    fun setRequireApproval(value: Boolean) = _state.update { it.copy(requireApproval = value) }

    fun openDangerDialog() = _state.update { it.copy(showDangerDialog = true) }
    fun closeDangerDialog() = _state.update { it.copy(showDangerDialog = false) }

    /** Пересборка текста штампа по текущим значениям полей. */
    fun rebuildPreview() {
        val s = _state.value
        val templateText = s.selectedSubTemplateId?.let { id ->
            s.subTemplates.firstOrNull { it.id == id }?.textTemplate
        } ?: composer.templateText(s.category, null)

        val path = s.fields[FieldKeys.TECH_TRACK].orEmpty().ifBlank {
            listOfNotNull(
                s.fields[FieldKeys.HOZ_TRACK_FROM]?.let { "от $it" },
                s.fields[FieldKeys.HOZ_TRACK_TO]?.let { "на $it" },
            ).joinToString(" → ")
        }
        val section = s.fields[FieldKeys.TECH_SECTION].orEmpty()
        val extra = s.fields[FieldKeys.TECH_EXTRA]
            ?: s.fields[FieldKeys.HOZ_OTHER_TRAIN].orEmpty()

        val composed = if (templateText.isBlank()) buildDefaultText(s) else composer(templateText, path, section, extra)
        _state.update { it.copy(bodyPreview = composed) }
    }

    private fun buildDefaultText(s: CreateOrderUiState): String {
        val stations = if (s.allStations) "Всем станциям"
        else s.targetStations.joinToString(", ")
        return buildString {
            append(categoryTitle(s.category))
            if (stations.isNotBlank()) append(" — $stations")
            append(". Время: ${s.fields[FieldKeys.TIME].orEmpty()}")
        }
    }

    /** Валидация формы. Возвращает true, если можно двигаться дальше. */
    fun validate(): Boolean {
        val s = _state.value
        return when (val result = validator(s.category, s.fields, null)) {
            ValidationResult.Valid -> {
                _state.update { it.copy(errors = emptyMap()) }
                if (!s.allStations && s.targetStations.isEmpty() &&
                    s.fields[FieldKeys.FROM_STATION].isNullOrBlank()
                ) {
                    _state.update { it.copy(errors = mapOf(FieldKeys.FROM_STATION to "Выберите станции, которым поступит приказ.")) }
                    false
                } else true
            }
            is ValidationResult.Invalid -> {
                _state.update { it.copy(errors = ValidationMessages.toMap(result.errors)) }
                _toast.value = ("Исправьте ошибки в форме (${result.errors.size})") to true
                false
            }
        }
    }

    /** Сохранить как заготовку (черновик). */
    fun saveAsTemplate() {
        if (!validate()) return
        val s = _state.value
        viewModelScope.launch {
            _state.update { it.copy(saving = true) }
            val order = buildOrder(draft = true, issued = false)
            orderRepo.upsert(order)
            _state.update { it.copy(saving = false) }
            _toast.value = "Черновик сохранён (заготовка)." to false
        }
    }

    /** Выдать приказ. Для опасных операций требует подтверждения из диалога. */
    fun issue() {
        val s = _state.value
        if (!validate()) return
        if (s.category.isDangerous) {
            _state.update { it.copy(showDangerDialog = true) }
            return
        }
        doIssue()
    }

    /** Подтверждение опасной операции (второй шаг). */
    fun confirmDangerAndIssue() {
        _state.update { it.copy(showDangerDialog = false) }
        doIssue()
    }

    private fun doIssue() {
        viewModelScope.launch {
            _state.update { it.copy(saving = true) }
            val order = buildOrder(draft = false, issued = true)
            val saved = orderRepo.upsert(order)
            val issued = orderRepo.issue(saved.id, order.issuedAt ?: shiftWindow.time(), _state.value.requireApproval)
            _state.update { it.copy(saving = false) }
            _toast.value = if (_state.value.requireApproval)
                "Приказ № ${issued.number} отправлен на утверждение." to false
            else
                "Приказ № ${issued.number} выдан." to false
            onIssued(issued)
        }
    }

    /** Колбэк после выдачи — задаёт экран-владелец для навигации. */
    var onIssued: (Order) -> Unit = {}

    private fun buildOrder(draft: Boolean, issued: Boolean): Order {
        val s = _state.value
        val user = auth.currentSnapshot
        val time = s.fields[FieldKeys.TIME].orEmpty().ifBlank { shiftWindow.time() }
        return Order(
            id = UUID.randomUUID().toString(),
            category = s.category,
            draft = draft,
            issuedAt = if (issued) time else null,
            fromStationCode = s.fields[FieldKeys.FROM_STATION],
            toStationCode = s.fields[FieldKeys.TO_STATION],
            allStations = s.allStations,
            targetStationCodes = s.targetStations.toList(),
            shift = Shift.ofTime(time),
            issuedByDch = user?.name,
            acceptedByDch = s.fields[FieldKeys.ACCEPTED_BY],
            handedByDch = s.fields[FieldKeys.HANDED_BY],
            body = s.bodyPreview,
            fields = s.fields,
            createdAt = System.currentTimeMillis(),
        )
    }

    fun clearToast() { _toast.value = null }
}

/** Заголовок категории на русском (для предпросмотра и CSV). */
fun categoryTitle(category: OrderCategory): String = when (category) {
    OrderCategory.SHIFT_HANDOVER -> "Приём и сдача дежурства"
    OrderCategory.HOZ_WRONG_DIR -> "Хозяйственный поезд в неправильном направлении"
    OrderCategory.AB_TO_ALS -> "Переход с АБ на АЛС-АРС"
    OrderCategory.ALS_TO_AB -> "Переход с АЛС-АРС на АБ"
    OrderCategory.ENERGY_DCH -> "Энергодиспетчеру (ЭЧЦ)"
    OrderCategory.VOLTAGE_OFF -> "О снятии напряжения"
    OrderCategory.TRACK_CLOSE -> "О закрытии пути (перегона)"
}
