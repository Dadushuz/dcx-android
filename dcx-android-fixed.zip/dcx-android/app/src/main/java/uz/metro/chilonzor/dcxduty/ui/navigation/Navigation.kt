package uz.metro.chilonzor.dcxduty.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.ui.graphics.vector.ImageVector

/** Маршруты навигации приложения. */
object Routes {
    const val LOGIN = "login"
    const val DUTY = "duty"
    const val JOURNAL = "journal"
    const val CREATE = "create"
    const val REPORTS = "reports"
    const val MORE = "more"
    const val TEMPLATES = "templates"
    const val LOGS = "logs"
    const val ADMIN = "admin"
}

/** Элемент нижней навигации. */
data class BottomTab(val route: String, val label: String, val icon: ImageVector)

/** Основные вкладки нижней панели (крупные и понятные — интерфейс дежурного). */
val BOTTOM_TABS: List<BottomTab> = listOf(
    BottomTab(Routes.DUTY, "Дежурство", Icons.Filled.Home),
    BottomTab(Routes.JOURNAL, "Журнал", Icons.Filled.Description),
    BottomTab(Routes.CREATE, "Приказ", Icons.Filled.Add),
    BottomTab(Routes.REPORTS, "Отчёты", Icons.Filled.Assessment),
    BottomTab(Routes.MORE, "Ещё", Icons.Filled.MoreHoriz),
)

/** Разделы экрана «Ещё» (шаблоны, логи, панель основателя). */
data class MoreEntry(val route: String, val label: String, val hint: String, val icon: ImageVector)

val MORE_ENTRIES: List<MoreEntry> = listOf(
    MoreEntry(Routes.TEMPLATES, "Заготовки приказов", "Шаблоны текстов по разделам", Icons.Filled.SwapHoriz),
    MoreEntry(Routes.LOGS, "Логи и аудит", "Последние 300 действий сотрудников", Icons.Filled.Description),
    MoreEntry(Routes.ADMIN, "Панель основателя", "Аккаунты, роли, нумерация, очистка", Icons.Filled.Settings),
)

/** Заголовок экрана по маршруту. */
fun routeTitle(route: String?): String = when (route) {
    Routes.DUTY -> "Дежурство ДЦХ"
    Routes.JOURNAL -> "Журнал приказов"
    Routes.CREATE -> "Выдача приказа"
    Routes.REPORTS -> "Отчёты и аналитика"
    Routes.MORE -> "Дополнительно"
    Routes.TEMPLATES -> "Заготовки приказов"
    Routes.LOGS -> "Системные логи"
    Routes.ADMIN -> "Панель основателя"
    else -> "АРМ ДЦХ"
}
