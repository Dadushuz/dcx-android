package uz.metro.chilonzor.dcxduty.domain.model

/** Учётная запись сотрудника / профиль текущего пользователя. */
data class UserProfile(
    val uid: String,
    val email: String = "",
    val name: String = "",
    val role: Role = Role.DCH,
    val stationCode: String? = null,
    val active: Boolean = true,
) {
    /** Отображаемое имя с привязкой к станции для работника станции. */
    val displayName: String
        get() = if (role == Role.STATION) "$name • ${Stations.full(stationCode)}" else name
}

/** Метаданные дежурства (активный/предыдущий ДЦХ, счётчик номеров). */
data class DutyMeta(
    val activeDch: String = "",
    val prevDch: String = "",
    val nextNumber: Int = 1,
    val updatedAt: Long = System.currentTimeMillis(),
)

/** Состояние синхронизации (для индикатора в шапке). */
enum class SyncState { SYNCED, PENDING, OFFLINE, ERROR }

/** Фильтры раздела "Отчёты". */
data class ReportFilter(
    val shift: Shift = Shift.NONE,
    val stationCode: String? = null,
    val category: OrderCategory? = null,
    val employee: String? = null,
    val dateFrom: Long? = null,
    val dateTo: Long? = null,
)

/** Сводка по отчёту. */
data class ReportSummary(
    val total: Int = 0,
    val pending: Int = 0,
    val issued: Int = 0,
    val journal: Int = 0,
    val canceled: Int = 0,
)
