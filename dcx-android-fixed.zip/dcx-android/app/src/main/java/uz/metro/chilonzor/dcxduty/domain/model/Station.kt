package uz.metro.chilonzor.dcxduty.domain.model

/** Станция Чиланзарской линии. [code] — короткий идентификатор, [full] — полное название. */
data class Station(val code: String, val full: String)

/** Перегон между двумя соседними станциями. */
data class Span(val fromCode: String, val toCode: String, val name: String)

/**
 * Справочник станций Чиланзарской линии (18 станций + электродепо).
 * Порядок соответствует реальной последовательности линии.
 */
object Stations {
    val list: List<Station> = listOf(
        Station("biy", "Буюк Ипак Йули"),
        Station("push", "Пушкин"),
        Station("holim", "Хамид Олимжон"),
        Station("atxiyo", "Амир Темур Хиёбони"),
        Station("must", "Мустакиллик майдони"),
        Station("paxt", "Пахтакор"),
        Station("xdust", "Халклар Дустлиги"),
        Station("mbog", "Миллий бог"),
        Station("nav", "Новза"),
        Station("mu", "Мирзо Улугбек"),
        Station("chil", "Чиланзар"),
        Station("olma", "Олмазор"),
        Station("chosh", "Чоштепа"),
        Station("uzg", "Узгариш"),
        Station("serg", "Сергели"),
        Station("yang", "Янгихаёт"),
        Station("chin", "Чинор"),
        Station("depo", "Блок-пост электродепо «Чиланзар»"),
    )

    private val byCode: Map<String, Station> = list.map { it.code to it }.toMap()

    fun full(code: String?): String = code?.let { byCode[it]?.full } ?: ""

    fun byCode(code: String?): Station? = code?.let { byCode[it] }

    /** Перегоны: пары соседних станций (электродепо в перегоны не входит). */
    val spans: List<Span> = list.dropLast(1).mapIndexed { i, s ->
        Span(s.code, list[i + 1].code, "«${s.full} — ${list[i + 1].full}»")
    }

    val codes: List<String> = list.map { it.code }

    /** Первая станция линии — используется как "От станции" по умолчанию. */
    val firstCode: String get() = list.first().code
    val lastCode: String get() = list.last().code
}
