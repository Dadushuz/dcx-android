package uz.metro.chilonzor.dcxduty.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.metro.chilonzor.dcxduty.ui.theme.DangerRed
import uz.metro.chilonzor.dcxduty.ui.theme.MetroAccent
import uz.metro.chilonzor.dcxduty.ui.theme.MetroBlue
import uz.metro.chilonzor.dcxduty.ui.viewmodel.LoginViewModel

/** Экран входа: электронная почта + пароль, понятные русские сообщения об ошибках. */
@Composable
fun LoginScreen(vm: LoginViewModel, onLoggedIn: () -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            // Эмблема и название
            Surface(color = MetroBlue, shape = RoundedCornerShape(20.dp)) {
                Column(
                    Modifier.padding(horizontal = 28.dp, vertical = 26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("🚇", style = MaterialTheme.typography.displaySmall, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Text("ЧИЛАНЗАРСКАЯ ЛИНИЯ",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White, fontWeight = FontWeight.Bold)
                    Text("АРМ ДЦХ — управление приказами",
                        style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.8f))
                }
            }

            Spacer(Modifier.height(24.dp))

            Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("Вход в начале смены. Повторно пароль не запрашивается до выхода.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(16.dp))

                    Text("Электронная почта", style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = s.email,
                        onValueChange = vm::onEmail,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        enabled = !s.loading,
                        placeholder = { Text("dch@chilonzor.uz") },
                        textStyle = MaterialTheme.typography.bodyLarge,
                        shape = RoundedCornerShape(10.dp),
                    )

                    Spacer(Modifier.height(12.dp))
                    Text("Пароль", style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = s.password,
                        onValueChange = vm::onPassword,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        enabled = !s.loading,
                        visualTransformation = PasswordVisualTransformation(),
                        textStyle = MaterialTheme.typography.bodyLarge,
                        shape = RoundedCornerShape(10.dp),
                    )

                    if (s.error != null) {
                        Spacer(Modifier.height(12.dp))
                        Surface(color = DangerRed.copy(alpha = 0.12f), shape = RoundedCornerShape(10.dp)) {
                            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                Icon(Icons.Filled.Info, null, tint = DangerRed, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.height(4.dp))
                                Text(s.error.orEmpty(), color = DangerRed,
                                    style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = { vm.login() },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        enabled = !s.loading,
                        colors = ButtonDefaults.buttonColors(containerColor = MetroBlue),
                    ) {
                        if (s.loading) {
                            CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(Modifier.height(0.dp))
                        } else {
                            Icon(Icons.Filled.Check, null, Modifier.size(20.dp))
                        }
                        Spacer(Modifier.size(10.dp))
                        Text(if (s.loading) "Вход…" else "Войти", style = MaterialTheme.typography.titleMedium)
                    }

                    Spacer(Modifier.height(10.dp))
                    Text("Забыли пароль? Обратитесь к администратору системы.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(20.dp))
            Surface(color = MetroAccent.copy(alpha = 0.18f), shape = RoundedCornerShape(10.dp)) {
                Text(
                    "Офлайн-режим: данные сохраняются на устройстве и отправятся при появлении связи.",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(12.dp),
                )
            }
        }
    }
}
