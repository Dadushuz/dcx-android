package uz.metro.chilonzor.dcxduty

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import uz.metro.chilonzor.dcxduty.data.repository.AuthRepositoryImpl
import uz.metro.chilonzor.dcxduty.di.AppContainer
import uz.metro.chilonzor.dcxduty.sync.SyncWorker

/** Точка входа приложения: DI-контейнер, восстановление сессии, фоновая синхронизация. */
class DcxApp : Application() {

    lateinit var container: AppContainer
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)

        // Восстановление сессии: если пользователь уже входил — сразу показываем рабочий экран.
        appScope.launch {
            runCatching { (container.authRepository as AuthRepositoryImpl).restoreSession() }
            runCatching { container.templateRepository.seedIfEmpty() }
            runCatching { container.orderRepository.pullFromRemote() }
        }

        // Периодическая синхронизация + попытка синхронизации при появлении сети.
        SyncWorker.schedulePeriodic(this)
        container.networkMonitor.onlineFlow
            .onEach { online -> if (online) SyncWorker.syncNow(this) }
            .launchIn(appScope)
    }
}
