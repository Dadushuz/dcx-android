package uz.metro.chilonzor.dcxduty.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow
import uz.metro.chilonzor.dcxduty.data.local.entity.LogEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.MetaEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.OrderEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.ProfileEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.TemplateEntity

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders WHERE deleted = 0 ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE deleted = 0 AND canceled = 0 AND draft = 0 AND approvedAt IS NULL ORDER BY createdAt DESC")
    fun observePending(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE deleted = 0 AND canceled = 0 AND draft = 0 AND approvedAt IS NOT NULL AND inPaperJournal = 0 ORDER BY createdAt DESC")
    fun observeNotInPaperJournal(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE deleted = 0 AND draft = 1 ORDER BY createdAt DESC")
    fun observeDrafts(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :id LIMIT 1")
    suspend fun byId(id: String): OrderEntity?

    @Query("SELECT * FROM orders WHERE dirty = 1")
    suspend fun dirty(): List<OrderEntity>

    @Query("SELECT COUNT(*) FROM orders WHERE dirty = 1")
    fun observeDirtyCount(): Flow<Int>

    @Query("SELECT MAX(number) FROM orders")
    suspend fun maxNumber(): Int?

    @Query("SELECT COUNT(*) FROM orders WHERE approvedAt IS NOT NULL AND createdAt < :before AND deleted = 0")
    suspend fun countApprovedBefore(before: Long): Int

    @Query("DELETE FROM orders WHERE approvedAt IS NOT NULL AND createdAt < :before")
    suspend fun deleteApprovedBefore(before: Long): Int

    @Upsert
    suspend fun upsert(entity: OrderEntity)

    @Upsert
    suspend fun upsertAll(entities: List<OrderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<OrderEntity>)

    @Query("DELETE FROM orders")
    suspend fun clear()

    @Query("DELETE FROM orders WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface LogDao {
    @Query("SELECT * FROM logs ORDER BY at DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<LogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: LogEntity)

    @Query("DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY at DESC LIMIT 300)")
    suspend fun trimTo300()

    @Query("DELETE FROM logs")
    suspend fun clear()

    @Query("SELECT * FROM logs")
    suspend fun all(): List<LogEntity>
}

@Dao
interface TemplateDao {
    @Query("SELECT * FROM templates ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<TemplateEntity>>

    @Query("SELECT * FROM templates")
    suspend fun all(): List<TemplateEntity>

    @Upsert
    suspend fun upsert(entity: TemplateEntity)

    @Upsert
    suspend fun upsertAll(entities: List<TemplateEntity>)

    @Query("DELETE FROM templates WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT COUNT(*) FROM templates")
    suspend fun count(): Int
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles WHERE active = 1")
    fun observeActive(): Flow<List<ProfileEntity>>

    @Query("SELECT * FROM profiles")
    suspend fun all(): List<ProfileEntity>

    @Query("SELECT * FROM profiles WHERE uid = :uid LIMIT 1")
    suspend fun byId(uid: String): ProfileEntity?

    @Upsert
    suspend fun upsert(entity: ProfileEntity)

    @Upsert
    suspend fun upsertAll(entities: List<ProfileEntity>)
}

@Dao
interface MetaDao {
    @Query("SELECT value FROM meta WHERE `key` = :key LIMIT 1")
    suspend fun get(key: String): String?

    @Query("SELECT value FROM meta WHERE `key` = :key LIMIT 1")
    fun observe(key: String): Flow<String?>

    @Upsert
    suspend fun put(entity: MetaEntity)
}
