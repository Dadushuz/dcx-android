package uz.metro.chilonzor.dcxduty.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import uz.metro.chilonzor.dcxduty.data.remote.AuthError
import uz.metro.chilonzor.dcxduty.data.remote.AuthException
import uz.metro.chilonzor.dcxduty.data.repository.AuthRepositoryImpl
import uz.metro.chilonzor.dcxduty.domain.model.UserProfile

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val loading: Boolean = false,
    val error: String? = null,
    val user: UserProfile? = null,
    val autoRestored: Boolean = false,
)

class LoginViewModel(private val auth: AuthRepositoryImpl) : ViewModel() {

    private val _state = MutableStateFlow(LoginUiState())
    val state: StateFlow<LoginUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            auth.restoreSession()
            val restored = auth.currentSnapshot
            _state.update { it.copy(user = restored, autoRestored = restored != null) }
        }
    }

    fun onEmail(value: String) = _state.update { it.copy(email = value, error = null) }
    fun onPassword(value: String) = _state.update { it.copy(password = value, error = null) }

    fun login() {
        val s = _state.value
        if (s.email.isBlank() || s.password.isBlank()) {
            _state.update { it.copy(error = "Введите электронную почту и пароль.") }
            return
        }
        if (!s.email.contains("@")) {
            _state.update { it.copy(error = "Некорректный адрес электронной почты.") }
            return
        }
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            auth.signIn(s.email, s.password)
                .onSuccess { profile ->
                    _state.update { it.copy(loading = false, user = profile, error = null) }
                }
                .onFailure { t ->
                    _state.update { it.copy(loading = false, error = message(t)) }
                }
        }
    }

    private fun message(t: Throwable): String = when ((t as? AuthException)?.reason) {
        AuthError.INVALID_CREDENTIALS -> "Не удалось войти: неверная почта или пароль."
        AuthError.NETWORK -> "Нет связи с сервером. Проверьте подключение к сети."
        AuthError.NOT_CONFIGURED -> "Сервис входа не настроен. Обратитесь к администратору."
        else -> "Ошибка входа: ${t.message ?: "неизвестная ошибка"}"
    }
}
