package uz.metro.chilonzor.dcxduty.data.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import uz.metro.chilonzor.dcxduty.data.local.DcxDatabase
import uz.metro.chilonzor.dcxduty.data.local.SessionStore
import uz.metro.chilonzor.dcxduty.data.local.entity.ProfileEntity
import uz.metro.chilonzor.dcxduty.data.remote.AuthError
import uz.metro.chilonzor.dcxduty.data.remote.AuthException
import uz.metro.chilonzor.dcxduty.data.remote.AuthRemoteDataSource
import uz.metro.chilonzor.dcxduty.data.remote.RemoteDatabaseSource
import uz.metro.chilonzor.dcxduty.data.remote.dto.ProfileDto
import uz.metro.chilonzor.dcxduty.domain.model.Role
import uz.metro.chilonzor.dcxduty.domain.model.UserProfile
import uz.metro.chilonzor.dcxduty.domain.repository.AuthRepository

/**
 * Аутентификация и профили сотрудников.
 * Сессия хранится в DataStore, профили кэшируются в Room и синхронизируются с RTDB.
 */
class AuthRepositoryImpl(
    private val db: DcxDatabase,
    private val auth: AuthRemoteDataSource,
    private val remote: RemoteDatabaseSource,
    private val session: SessionStore,
) : AuthRepository {

    private val current = MutableStateFlow<UserProfile?>(null)
    override val currentUser: Flow<UserProfile?> = current.asStateFlow()

    /** Синхронный снимок профиля (для провайдеров логов и проверки ролей). */
    val currentSnapshot: UserProfile? get() = current.value

    /** Восстановление сессии при старте приложения. */
    suspend fun restoreSession() {
        val uid = session.uid() ?: return
        val cached = db.profileDao().byId(uid)
        if (cached != null) {
            current.value = cached.toDomain()
            return
        }
        val token = session.token()
        val dto = remote.fetchProfileRest(uid, token)
        if (dto != null) {
            db.profileDao().upsert(dto.toEntity())
            current.value = dto.toDomain()
        }
    }

    override suspend fun signIn(email: String, password: String): Result<UserProfile> = runCatching {
        val authSession = auth.signIn(email.trim(), password)
        session.save(authSession.uid, authSession.idToken, authSession.email)

        // Профиль: сначала локальный кэш, затем RTDB.
        val local = db.profileDao().byId(authSession.uid)
        val profile = local?.toDomain() ?: run {
            val dto = remote.fetchProfileRest(authSession.uid, authSession.idToken)
            if (dto != null) {
                db.profileDao().upsert(dto.toEntity())
                dto.toDomain()
            } else {
                // Первый вход основателя: профиль ещё не создан в базе.
                UserProfile(
                    uid = authSession.uid,
                    email = authSession.email,
                    name = authSession.email.substringBefore("@").replaceFirstChar { it.uppercase() },
                    role = Role.DCH,
                ).also {
                    db.profileDao().upsert(it.toEntity())
                    remote.pushProfileRest(it.toDto(), authSession.idToken)
                }
            }
        }
        current.value = profile
        profile
    }.recoverCatching { t ->
        throw mapError(t)
    }

    override suspend fun signOut(): Result<Unit> = runCatching {
        auth.signOut()
        current.value = null
        session.clear()
    }

    override suspend fun createAccount(
        email: String,
        password: String,
        profile: UserProfile,
    ): Result<UserProfile> = runCatching {
        val uid = auth.createAccount(email.trim(), password)
        val full = profile.copy(uid = uid, email = email.trim())
        db.profileDao().upsert(full.toEntity())
        val token = session.token()
        remote.pushProfileRest(full.toDto(), token)
        full
    }

    override suspend fun listAccounts(): List<UserProfile> {
        val token = session.token()
        val remoteList = remote.fetchProfilesRest(token)
        if (remoteList.isNotEmpty()) {
            db.profileDao().upsertAll(remoteList.map { it.toEntity() })
        }
        return db.profileDao().all().map { it.toDomain() }
    }

    private fun mapError(t: Throwable): Throwable = when (t) {
        is AuthException -> t
        else -> {
            val msg = t.message.orEmpty()
            when {
                msg.contains("timeout", true) || msg.contains("Unable to resolve host", true) ||
                    msg.contains("network", true) -> AuthException(AuthError.NETWORK, msg)
                msg.contains("password", true) || msg.contains("credential", true) ->
                    AuthException(AuthError.INVALID_CREDENTIALS, msg)
                else -> AuthException(AuthError.UNKNOWN, msg)
            }
        }
    }
}

/** Преобразования профиля (домен ↔ Room ↔ RTDB). */
fun ProfileEntity.toDomain() = UserProfile(
    uid = uid,
    email = email,
    name = name,
    role = runCatching { Role.valueOf(roleName) }.getOrDefault(Role.DCH),
    stationCode = stationCode,
    active = active,
)

fun UserProfile.toEntity() = ProfileEntity(
    uid = uid,
    email = email,
    name = name,
    roleName = role.name,
    stationCode = stationCode,
    active = active,
)

fun UserProfile.toDto() = ProfileDto().apply {
    uid = this@toDto.uid
    email = this@toDto.email
    name = this@toDto.name
    role = this@toDto.role.name.lowercase()
    stationCode = this@toDto.stationCode
    active = this@toDto.active
}

fun ProfileDto.toDomain() = UserProfile(
    uid = uid,
    email = email,
    name = name,
    role = when (role.lowercase()) {
        "founder" -> Role.FOUNDER
        "chief" -> Role.CHIEF
        "station" -> Role.STATION
        else -> Role.DCH
    },
    stationCode = stationCode,
    active = active,
)

fun ProfileDto.toEntity() = ProfileEntity(
    uid = uid,
    email = email,
    name = name,
    roleName = role.uppercase(),
    stationCode = stationCode,
    active = active,
)
