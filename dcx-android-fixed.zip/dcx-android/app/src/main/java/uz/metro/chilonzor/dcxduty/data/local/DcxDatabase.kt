package uz.metro.chilonzor.dcxduty.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import uz.metro.chilonzor.dcxduty.data.local.dao.LogDao
import uz.metro.chilonzor.dcxduty.data.local.dao.MetaDao
import uz.metro.chilonzor.dcxduty.data.local.dao.OrderDao
import uz.metro.chilonzor.dcxduty.data.local.dao.ProfileDao
import uz.metro.chilonzor.dcxduty.data.local.dao.TemplateDao
import uz.metro.chilonzor.dcxduty.data.local.entity.LogEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.MetaEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.OrderEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.ProfileEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.TemplateEntity

@Database(
    entities = [
        OrderEntity::class,
        LogEntity::class,
        TemplateEntity::class,
        ProfileEntity::class,
        MetaEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class DcxDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao
    abstract fun logDao(): LogDao
    abstract fun templateDao(): TemplateDao
    abstract fun profileDao(): ProfileDao
    abstract fun metaDao(): MetaDao

    companion object {
        @Volatile private var INSTANCE: DcxDatabase? = null

        fun get(context: Context): DcxDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                DcxDatabase::class.java,
                "dcx_duty.db",
            )
                .fallbackToDestructiveMigration()
                .build()
                .also { INSTANCE = it }
        }
    }
}
