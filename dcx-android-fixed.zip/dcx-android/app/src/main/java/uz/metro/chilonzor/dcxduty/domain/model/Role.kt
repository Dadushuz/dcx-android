package uz.metro.chilonzor.dcxduty.domain.model

/** Роли пользователя в системе АРМ ДЦХ. */
enum class Role {
    FOUNDER,   // Основатель — полный доступ (панель управления)
    CHIEF,     // Старший ДЦХ — утверждение приказов
    DCH,       // ДЦХ — выдача приказов, ведение журнала
    STATION;   // Работник станции — просмотр поступивших приказов

    /** Может создавать и выдавать приказы. */
    val canIssue: Boolean get() = this == DCH || this == CHIEF || this == FOUNDER

    /** Может утверждать приказы (снимать статус "НА УТВЕРЖДЕНИИ"). */
    val canApprove: Boolean get() = this == CHIEF || this == FOUNDER

    /** Полный доступ к панели основателя (аккаунты, шаблоны, нумерация). */
    val canAdmin: Boolean get() = this == FOUNDER

    /** Может вносить приказ в бумажный журнал. */
    val canJournal: Boolean get() = this == DCH || this == CHIEF || this == FOUNDER
}
