package uz.metro.chilonzor.dcxduty.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import uz.metro.chilonzor.dcxduty.data.remote.NetworkMonitor
import uz.metro.chilonzor.dcxduty.data.repository.AuthRepositoryImpl
import uz.metro.chilonzor.dcxduty.domain.model.DutyMeta
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.OrderStatus
import uz.metro.chilonzor.dcxduty.domain.model.SyncState
import uz.metro.chilonzor.dcxduty.domain.model.UserProfile
import uz.metro.chilonzor.dcxduty.domain.repository.DutyRepository
import uz.metro.chilonzor.dcxduty.domain.repository.OrderRepository
import uz.metro.chilonzor.dcxduty.domain.usecase.ShiftWindowUseCase
import uz.metro.chilonzor.dcxduty.domain.usecase.ValidateOrderUseCase

/** Состояние шапки приложения: пользователь, сеть, очередь несохранённого. */
data class AppShellState(
    val user: UserProfile? = null,
    val online: Boolean = true,
    val pendingSync: Int = 0,
    val syncState: SyncState = SyncState.SYNCED,
    val activeDch: String = "",
    val nextNumber: Int = 1,
    val toast: String? = null,
    val toastError: Boolean = false,
)

class AppShellViewModel(
    private val auth: AuthRepositoryImpl,
    private val orderRepo: OrderRepository,
    private val dutyRepo: DutyRepository,
    private val network: NetworkMonitor,
) : ViewModel() {

    private val _toast = MutableStateFlow<Pair<String, Boolean>?>(null)

    val state: StateFlow<AppShellState> = combine(
        auth.currentUser,
        network.onlineFlow,
        orderRepo.observePendingCount(),
        orderRepo.observeSyncState(),
        dutyRepo.observeMeta(),
    ) { user, online, pending, sync, meta ->
        AppShellState(
            user = user,
            online = online,
            pendingSync = pending,
            syncState = sync,
            activeDch = meta.activeDch,
            nextNumber = meta.nextNumber,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppShellState())

    val toast: StateFlow<Pair<String, Boolean>?> = _toast.asStateFlow()

    fun showToast(message: String, isError: Boolean = false) { _toast.value = message to isError }
    fun clearToast() { _toast.value = null }

    fun syncNow() {
        viewModelScope.launch {
            val sent = runCatching { orderRepo.syncNow() }.getOrElse { -1 }
            if (sent < 0) showToast("Синхронизация не удалась: нет связи с сервером.", true)
            else if (sent == 0) showToast("Все данные уже синхронизированы.")
            else showToast("Синхронизация выполнена: $sent записей.")
        }
    }

    fun logout(onDone: () -> Unit) {
        viewModelScope.launch {
            auth.signOut()
            onDone()
        }
    }
}

/** Состояние экрана дежурства + сводка по приказам. */
data class DutyUiState(
    val user: UserProfile? = null,
    val meta: DutyMeta = DutyMeta(),
    val shiftWindowOpen: Boolean = false,
    val nowText: String = "",
    val total: Int = 0,
    val pending: Int = 0,
    val notInJournal: Int = 0,
    val drafts: Int = 0,
    val lastOrders: List<Order> = emptyList(),
    val acceptedNameInput: String = "",
    val handoverIncomingInput: String = "",
    val handoverOutgoingInput: String = "",
)

class DutyViewModel(
    private val auth: AuthRepositoryImpl,
    private val orderRepo: OrderRepository,
    private val dutyRepo: DutyRepository,
    private val shiftWindow: ShiftWindowUseCase,
) : ViewModel() {

    private val _local = MutableStateFlow(DutyUiState())
    private val _toast = MutableStateFlow<Pair<String, Boolean>?>(null)
    val toast: StateFlow<Pair<String, Boolean>?> = _toast.asStateFlow()

    val state: StateFlow<DutyUiState> = combine(
        _local,
        auth.currentUser,
        dutyRepo.observeMeta(),
        orderRepo.observeAll(),
    ) { local, user, meta, orders ->
        local.copy(
            user = user,
            meta = meta,
            shiftWindowOpen = shiftWindow(),
            nowText = shiftWindow.dateTime(),
            total = orders.size,
            pending = orders.count { it.status == OrderStatus.PENDING },
            notInJournal = orders.count { it.status == OrderStatus.ISSUED },
            drafts = orders.count { it.draft },
            lastOrders = orders.take(5),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DutyUiState())

    fun onAcceptedName(v: String) = _local.update { it.copy(acceptedNameInput = v) }
    fun onHandoverIncoming(v: String) = _local.update { it.copy(handoverIncomingInput = v) }
    fun onHandoverOutgoing(v: String) = _local.update { it.copy(handoverOutgoingInput = v) }

    /** Приём дежурства: фиксирует ФИО дежурного текущей смены. */
    fun acceptDuty() {
        val name = _local.value.acceptedNameInput.trim()
        if (name.length < 3) {
            showToast("Укажите фамилию дежурного (не менее 3 символов).", true); return
        }
        viewModelScope.launch {
            dutyRepo.acceptDuty(name)
            showToast("Дежурство принято: $name")
        }
    }

    /** Приём и сдача дежурства: смена дежурного с фиксацией предыдущего. */
    fun handoverDuty() {
        val incoming = _local.value.handoverIncomingInput.trim()
        val outgoing = _local.value.handoverOutgoingInput.trim().ifBlank { state.value.meta.activeDch }
        if (incoming.length < 3) {
            showToast("Укажите фамилию принимающего дежурного.", true); return
        }
        if (outgoing.length < 3) {
            showToast("Укажите фамилию сдающего дежурного.", true); return
        }
        if (incoming.equals(outgoing, ignoreCase = true)) {
            showToast("Принимающий и сдающий не могут совпадать.", true); return
        }
        viewModelScope.launch {
            dutyRepo.handoverDuty(incoming, outgoing)
            _local.update { it.copy(handoverIncomingInput = "", handoverOutgoingInput = "") }
            showToast("Дежурство передано: $outgoing → $incoming")
        }
    }

    private fun showToast(msg: String, err: Boolean = false) { _toast.value = msg to err }
    fun clearToast() { _toast.value = null }
}

/** Валидатор формы наружу (для экрана создания приказа). */
fun createValidator(): ValidateOrderUseCase = ValidateOrderUseCase()
