package uz.metro.chilonzor.dcxduty.domain.model

/** Результат валидации формы приказа. */
sealed interface ValidationResult {
    data object Valid : ValidationResult
    data class Invalid(val errors: List<FieldError>) : ValidationResult
}

/** Ошибка конкретного поля формы. */
data class FieldError(val fieldKey: String, val messageRes: String)

/** Ключи полей формы (совпадают с web-версией, где это возможно). */
object FieldKeys {
    const val TIME = "b-time"
    const val FROM_STATION = "b-from-st"
    const val TO_STATION = "b-to-st"
    const val ACCEPTED_BY = "sh-accepted"
    const val HANDED_BY = "sh-handed"
    const val HOZ_TRAIN = "hoz-train"
    const val HOZ_TRACK_FROM = "hoz-tr1"
    const val HOZ_TRACK_TO = "hoz-tr2"
    const val HOZ_DEP_TYPE = "hoz-dep-type"
    const val HOZ_DEP_STATION = "hoz-dep-station"
    const val HOZ_DEP_SPAN = "hoz-dep-peregon"
    const val HOZ_DEST_STATION = "hoz-dest-station"
    const val HOZ_OTHER_TRAIN = "hoz-oth-num"
    const val TECH_TRACK = "tech-track"
    const val TECH_SECTION = "tech-section"
    const val TECH_EXTRA = "tech-extra"
}
