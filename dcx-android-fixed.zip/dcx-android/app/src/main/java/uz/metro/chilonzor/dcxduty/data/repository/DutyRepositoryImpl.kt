package uz.metro.chilonzor.dcxduty.data.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import uz.metro.chilonzor.dcxduty.data.local.DcxDatabase
import uz.metro.chilonzor.dcxduty.data.local.entity.LogEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.MetaEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.TemplateEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.toDomain
import uz.metro.chilonzor.dcxduty.data.local.entity.toEntity
import uz.metro.chilonzor.dcxduty.data.remote.RemoteDatabaseSource
import uz.metro.chilonzor.dcxduty.data.remote.dto.LogDto
import uz.metro.chilonzor.dcxduty.data.remote.dto.MetaDto
import uz.metro.chilonzor.dcxduty.data.remote.dto.TemplateDto
import uz.metro.chilonzor.dcxduty.domain.model.DefaultTemplates
import uz.metro.chilonzor.dcxduty.domain.model.DutyMeta
import uz.metro.chilonzor.dcxduty.domain.model.LogEntry
import uz.metro.chilonzor.dcxduty.domain.model.OrderCategory
import uz.metro.chilonzor.dcxduty.domain.model.OrderTemplate
import uz.metro.chilonzor.dcxduty.domain.repository.DutyRepository
import uz.metro.chilonzor.dcxduty.domain.repository.LogRepository
import uz.metro.chilonzor.dcxduty.domain.repository.TemplateRepository
import java.util.UUID

/** Дежурства: активный и предыдущий ДЦХ, время пересменки. */
class DutyRepositoryImpl(
    private val db: DcxDatabase,
    private val remote: RemoteDatabaseSource,
    private val tokenProvider: suspend () -> String?,
) : DutyRepository {

    override fun observeMeta(): Flow<DutyMeta> = db.metaDao().observe(KEY_META).map { raw ->
        if (raw.isNullOrBlank()) DutyMeta() else parseMeta(raw)
    }

    override suspend fun acceptDuty(dchName: String, at: Long) {
        val current = readMeta()
        val updated = current.copy(activeDch = dchName, updatedAt = at)
        persist(updated)
    }

    override suspend fun handoverDuty(incomingName: String, outgoingName: String, at: Long) {
        val current = readMeta()
        val updated = current.copy(
            activeDch = incomingName,
            prevDch = outgoingName.ifBlank { current.activeDch },
            updatedAt = at,
        )
        persist(updated)
    }

    private suspend fun readMeta(): DutyMeta =
        db.metaDao().get(KEY_META)?.let { parseMeta(it) } ?: DutyMeta()

    private suspend fun persist(meta: DutyMeta) {
        db.metaDao().put(MetaEntity(KEY_META, serializeMeta(meta)))
        val dto = MetaDto().apply {
            activeDch = meta.activeDch
            prevDch = meta.prevDch
            next = meta.nextNumber
            upd = meta.updatedAt
        }
        runCatching {
            if (remote.isSdkReady) remote.pushMetaSdk(dto) else remote.pushMetaRest(dto, tokenProvider())
        }
    }

    private fun serializeMeta(m: DutyMeta) = "${m.activeDch}\u001F${m.prevDch}\u001F${m.nextNumber}\u001F${m.updatedAt}"

    private fun parseMeta(raw: String): DutyMeta {
        val p = raw.split('\u001F')
        return DutyMeta(
            activeDch = p.getOrNull(0).orEmpty(),
            prevDch = p.getOrNull(1).orEmpty(),
            nextNumber = p.getOrNull(2)?.toIntOrNull() ?: 1,
            updatedAt = p.getOrNull(3)?.toLongOrNull() ?: 0L,
        )
    }

    companion object { const val KEY_META = "duty_meta" }
}

/** Шаблоны (заготовки) приказов: при первом запуске заполняются значениями по умолчанию. */
class TemplateRepositoryImpl(private val db: DcxDatabase) : TemplateRepository {

    override fun observeAll(): Flow<List<OrderTemplate>> =
        db.templateDao().observeAll().map { list -> list.map { it.toDomain() } }

    /** Инициализация справочника подшаблонов при первом запуске. */
    suspend fun seedIfEmpty() {
        if (db.templateDao().count() > 0) return
        db.templateDao().upsertAll(DefaultTemplates.items.map { it.toEntity() })
    }

    override suspend fun save(template: OrderTemplate) {
        db.templateDao().upsert(template.toEntity())
    }

    override suspend fun remove(id: String) {
        db.templateDao().deleteById(id)
    }
}

/** Системные логи (аудит действий). */
class LogRepositoryImpl(
    private val db: DcxDatabase,
    private val remote: RemoteDatabaseSource,
    private val tokenProvider: suspend () -> String?,
) : LogRepository {

    override fun observeRecent(limit: Int): Flow<List<LogEntry>> =
        db.logDao().observeRecent(limit).map { list -> list.map { it.toDomain() } }

    override suspend fun log(action: String, user: String, at: Long) {
        val entry = LogEntry(id = UUID.randomUUID().toString(), at = at, user = user, action = action)
        db.logDao().insert(entry.toEntity())
        db.logDao().trimTo300()
        val dto = LogDto().apply { id = entry.id; this.at = entry.at; this.user = entry.user; this.action = entry.action }
        runCatching {
            if (remote.isSdkReady) remote.pushLogSdk(dto) else remote.pushLogRest(dto, tokenProvider())
        }
    }

    override suspend fun clear() {
        db.logDao().clear()
    }
}

private fun TemplateEntity.toDomain() = OrderTemplate(
    id = id,
    category = OrderCategory.fromCode(categoryCode) ?: OrderCategory.SHIFT_HANDOVER,
    title = title,
    textTemplate = textTemplate,
    updatedAt = updatedAt,
)

private fun OrderTemplate.toEntity() = TemplateEntity(
    id = id,
    categoryCode = category.code,
    title = title,
    textTemplate = textTemplate,
    updatedAt = updatedAt,
)
