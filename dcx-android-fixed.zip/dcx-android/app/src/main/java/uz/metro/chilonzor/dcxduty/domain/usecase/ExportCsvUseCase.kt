package uz.metro.chilonzor.dcxduty.domain.usecase

import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.OrderCategory
import uz.metro.chilonzor.dcxduty.domain.model.OrderStatus
import uz.metro.chilonzor.dcxduty.domain.model.ReportSummary
import uz.metro.chilonzor.dcxduty.domain.model.Stations

/**
 * Формирование CSV-отчёта. Разделитель — точка с запятой (для Excel в русской локали),
 * кодировка UTF-8 с BOM, чтобы Excel корректно открывал кириллицу.
 */
class ExportCsvUseCase {

    fun summary(orders: List<Order>): ReportSummary = ReportSummary(
        total = orders.size,
        pending = orders.count { it.status == OrderStatus.PENDING },
        issued = orders.count { it.status == OrderStatus.ISSUED },
        journal = orders.count { it.status == OrderStatus.JOURNAL },
        canceled = orders.count { it.status == OrderStatus.CANCELED },
    )

    fun export(orders: List<Order>, categoryLabel: (OrderCategory) -> String): String {
        val sb = StringBuilder()
        sb.append('\uFEFF') // BOM для Excel
        sb.append("№;Дата и время;Тип приказа;ДЦХ;Станции;Статус;Текст\n")
        orders.sortedBy { it.createdAt }.forEach { o ->
            sb.append(csv(o.number?.toString() ?: "—")).append(';')
                .append(csv(fmt(o.createdAt))).append(';')
                .append(csv(categoryLabel(o.category))).append(';')
                .append(csv(o.issuedByDch ?: "—")).append(';')
                .append(csv(o.stationSummary())).append(';')
                .append(csv(statusLabel(o.status))).append(';')
                .append(csv(o.body.replace("\n", " ")))
                .append('\n')
        }
        return sb.toString()
    }

    fun exportJournal(orders: List<Order>, categoryLabel: (OrderCategory) -> String): String =
        export(orders, categoryLabel)

    private fun csv(value: String): String {
        val needsQuote = value.contains(';') || value.contains('"') || value.contains('\n')
        val escaped = value.replace("\"", "\"\"")
        return if (needsQuote) "\"$escaped\"" else escaped
    }

    private fun fmt(ts: Long): String =
        java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale("ru")).format(java.util.Date(ts))

    private fun statusLabel(status: OrderStatus): String = when (status) {
        OrderStatus.DRAFT -> "ЧЕРНОВИК"
        OrderStatus.PENDING -> "НА УТВЕРЖДЕНИИ"
        OrderStatus.ISSUED -> "ВЫДАН"
        OrderStatus.JOURNAL -> "ВНЕСЁН В ЖУРНАЛ"
        OrderStatus.CANCELED -> "ОТМЕНЁН"
    }
}
