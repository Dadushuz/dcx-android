package uz.metro.chilonzor.dcxduty.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import uz.metro.chilonzor.dcxduty.domain.model.LogEntry

/** Локальная запись системного лога (Room). */
@Entity(tableName = "logs")
data class LogEntity(
    @PrimaryKey val id: String,
    val at: Long,
    val user: String,
    val action: String,
)

fun LogEntity.toDomain(): LogEntry = LogEntry(id = id, at = at, user = user, action = action)
fun LogEntry.toEntity(): LogEntity = LogEntity(id = id, at = at, user = user, action = action)

/** Локальная запись шаблона (Room). */
@Entity(tableName = "templates")
data class TemplateEntity(
    @PrimaryKey val id: String,
    val categoryCode: String,
    val title: String,
    val textTemplate: String,
    val updatedAt: Long,
)

/** Локальная запись профиля сотрудника (Room). */
@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val uid: String,
    val email: String,
    val name: String,
    val roleName: String,
    val stationCode: String?,
    val active: Boolean,
)

/** Простая таблица "ключ-значение" для метаданных (нумерация, дежурный и т.п.). */
@Entity(tableName = "meta")
data class MetaEntity(
    @PrimaryKey val key: String,
    val value: String,
)
