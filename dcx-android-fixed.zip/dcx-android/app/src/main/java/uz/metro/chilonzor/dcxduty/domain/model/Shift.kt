package uz.metro.chilonzor.dcxduty.domain.model

/** Смена дежурства. Пересменка в 08:00 и 20:00. */
enum class Shift {
    DAY,    // Дневная (08:00–20:00)
    NIGHT,  // Ночная (20:00–08:00)
    NONE;   // Не определена / все смены

    companion object {
        /** Определяет смену по часу суток (локальное время). */
        fun ofHour(hour: Int): Shift = if (hour in 8..19) DAY else NIGHT

        /** Определяет смену по строке времени "ЧЧ:ММ". */
        fun ofTime(time: String?): Shift {
            val h = time?.substringBefore(":")?.toIntOrNull() ?: return NONE
            return ofHour(h)
        }
    }
}
