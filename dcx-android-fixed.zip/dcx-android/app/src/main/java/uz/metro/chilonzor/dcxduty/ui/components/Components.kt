package uz.metro.chilonzor.dcxduty.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import uz.metro.chilonzor.dcxduty.domain.model.OrderStatus
import uz.metro.chilonzor.dcxduty.domain.model.Role
import uz.metro.chilonzor.dcxduty.domain.model.Stations
import uz.metro.chilonzor.dcxduty.ui.theme.DangerRed
import uz.metro.chilonzor.dcxduty.ui.theme.StatusCanceled
import uz.metro.chilonzor.dcxduty.ui.theme.StatusDraft
import uz.metro.chilonzor.dcxduty.ui.theme.StatusIssued
import uz.metro.chilonzor.dcxduty.ui.theme.StatusJournal
import uz.metro.chilonzor.dcxduty.ui.theme.StatusPending

/** Цвет и подпись статуса приказа. */
fun OrderStatus.label(): String = when (this) {
    OrderStatus.DRAFT -> "ЧЕРНОВИК"
    OrderStatus.PENDING -> "НА УТВЕРЖДЕНИИ"
    OrderStatus.ISSUED -> "ВЫДАН"
    OrderStatus.JOURNAL -> "ВНЕСЁН В ЖУРНАЛ"
    OrderStatus.CANCELED -> "ОТМЕНЁН"
}

fun OrderStatus.color(): Color = when (this) {
    OrderStatus.DRAFT -> StatusDraft
    OrderStatus.PENDING -> StatusPending
    OrderStatus.ISSUED -> StatusIssued
    OrderStatus.JOURNAL -> StatusJournal
    OrderStatus.CANCELED -> StatusCanceled
}

fun Role.label(): String = when (this) {
    Role.FOUNDER -> "ОСНОВАТЕЛЬ"
    Role.CHIEF -> "СТАРШИЙ ДЦХ"
    Role.DCH -> "ДЦХ"
    Role.STATION -> "Работник станции"
}

/** Плашка статуса приказа (крупная, читаемая одним взглядом). */
@Composable
fun StatusChip(status: OrderStatus, modifier: Modifier = Modifier) {
    val c = status.color()
    Surface(
        modifier = modifier,
        color = c.copy(alpha = 0.12f),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, c),
    ) {
        Text(
            text = status.label(),
            color = c,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        )
    }
}

/** Плашка роли пользователя. */
@Composable
fun RolePill(role: Role, modifier: Modifier = Modifier) {
    val bg = when (role) {
        Role.FOUNDER -> Color(0xFF5B21B6)
        Role.CHIEF -> Color(0xFF0E7490)
        Role.DCH -> Color(0xFF0B3C74)
        Role.STATION -> Color(0xFF4B5563)
    }
    Surface(modifier = modifier, color = bg, shape = RoundedCornerShape(50)) {
        Text(
            text = role.label(),
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
        )
    }
}

/** Карточка-раздел с заголовком. */
@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    trailing: @Composable (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    subtitle?.let {
                        Text(it, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                trailing?.invoke()
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

/** Обязательная подпись поля формы. */
@Composable
fun FieldLabel(text: String, required: Boolean = false, error: String? = null) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = if (required) "$text *" else text,
            style = MaterialTheme.typography.labelLarge,
            color = if (error != null) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    error?.let {
        Text(it, style = MaterialTheme.typography.labelMedium, color = DangerRed)
    }
}

/** Текстовое поле с поддержкой ошибки. */
@Composable
fun DcxTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    required: Boolean = false,
    error: String? = null,
    placeholder: String? = null,
    singleLine: Boolean = true,
    enabled: Boolean = true,
    minLines: Int = 1,
) {
    Column(modifier) {
        FieldLabel(label, required, error)
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            isError = error != null,
            enabled = enabled,
            singleLine = singleLine,
            minLines = minLines,
            placeholder = placeholder?.let { { Text(it, color = MaterialTheme.colorScheme.outline) } },
            textStyle = MaterialTheme.typography.bodyLarge,
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = if (error != null) DangerRed else MaterialTheme.colorScheme.outline,
            ),
        )
    }
}

/** Выпадающий список (Material3 ExposedDropdownMenu). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> DcxDropdown(
    label: String,
    options: List<T>,
    selected: T?,
    optionLabel: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    required: Boolean = false,
    error: String? = null,
    enabled: Boolean = true,
    placeholder: String = "— выберите —",
) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier) {
        FieldLabel(label, required, error)
        Spacer(Modifier.height(4.dp))
        ExposedDropdownMenuBox(
            expanded = expanded && enabled,
            onExpandedChange = { if (enabled) expanded = it },
        ) {
            OutlinedTextField(
                value = selected?.let(optionLabel) ?: "",
                onValueChange = {},
                readOnly = true,
                enabled = enabled,
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                isError = error != null,
                placeholder = { Text(placeholder, color = MaterialTheme.colorScheme.outline) },
                textStyle = MaterialTheme.typography.bodyLarge,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                shape = RoundedCornerShape(10.dp),
            )
            ExposedDropdownMenu(expanded = expanded && enabled, onDismissRequest = { expanded = false }) {
                options.forEach { opt ->
                    DropdownMenuItem(
                        text = { Text(optionLabel(opt), style = MaterialTheme.typography.bodyLarge) },
                        onClick = { onSelect(opt); expanded = false },
                    )
                }
            }
        }
    }
}

/** Список станций — удобная обёртка над DcxDropdown. */
@Composable
fun StationDropdown(
    label: String,
    selectedCode: String?,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    required: Boolean = false,
    error: String? = null,
    enabled: Boolean = true,
) {
    DcxDropdown(
        label = label,
        options = Stations.list,
        selected = Stations.byCode(selectedCode),
        optionLabel = { it.full },
        onSelect = { onSelect(it.code) },
        modifier = modifier,
        required = required,
        error = error,
        enabled = enabled,
        placeholder = "— выберите станцию —",
    )
}

/** Группа переключателей-чипов (для путей, границ, отправления). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> OptionChips(
    label: String,
    options: List<T>,
    selected: T?,
    optionLabel: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    required: Boolean = false,
    error: String? = null,
) {
    Column(modifier) {
        FieldLabel(label, required, error)
        Spacer(Modifier.height(6.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { opt ->
                val isSelected = opt == selected
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelect(opt) },
                    label = { Text(optionLabel(opt), style = MaterialTheme.typography.bodyLarge) },
                    leadingIcon = if (isSelected) {
                        { Icon(Icons.Filled.Check, contentDescription = null, Modifier.size(18.dp)) }
                    } else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    ),
                )
            }
        }
    }
}

/** Пустой экран-заглушка. */
@Composable
fun EmptyState(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Info, contentDescription = null,
                tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(8.dp))
            Text(text, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyLarge)
        }
    }
}

/** Информационный баннер (онлайн/офлайн/очередь). */
@Composable
fun InfoBanner(text: String, color: Color, modifier: Modifier = Modifier) {
    Surface(modifier.fillMaxWidth(), color = color.copy(alpha = 0.14f)) {
        Text(
            text = text,
            color = color,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
        )
    }
}

/** Обычное подтверждение действия (безопасное). */
@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmText: String = "Подтвердить",
    dismissText: String = "Отмена",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = { Text(text, style = MaterialTheme.typography.bodyLarge) },
        confirmButton = {
            Button(onClick = onConfirm) { Text(confirmText) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(dismissText) }
        },
    )
}

/**
 * Диалог подтверждения ОПАСНОЙ операции (снятие напряжения / закрытие пути).
 *
 * Второй шаг защиты: кнопка "Подтвердить" заблокирована, пока дежурный не установит
 * галочку "Я осознаю последствия". Раньше это было невозможно из-за native confirm(),
 * который молча блокируется внутри WebView — здесь защита работает всегда.
 */
@Composable
fun DangerConfirmDialog(
    title: String,
    dangerText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    actionLabel: String = "Выдать приказ",
) {
    var acknowledged by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Warning, contentDescription = null, tint = DangerRed, modifier = Modifier.size(36.dp)) },
        title = {
            Text("⚠ ОПАСНАЯ ОПЕРАЦИЯ",
                style = MaterialTheme.typography.headlineSmall, color = DangerRed, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Surface(color = DangerRed.copy(alpha = 0.08f), shape = RoundedCornerShape(10.dp)) {
                    Text(dangerText, style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(12.dp))
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = acknowledged, onCheckedChange = { acknowledged = it })
                    Spacer(Modifier.width(4.dp))
                    Text("Я осознаю последствия", style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = acknowledged,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DangerRed,
                    disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                ),
            ) {
                Icon(Icons.Filled.Check, contentDescription = null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Подтвердить и $actionLabel")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Icon(Icons.Filled.Close, contentDescription = null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Отмена")
            }
        },
    )
}

/** Всплывающее сообщение об успехе/ошибке поверх экрана. */
@Composable
fun ToastHost(message: String?, isError: Boolean, modifier: Modifier = Modifier) {
    AnimatedVisibility(visible = message != null, modifier = modifier) {
        Surface(
            color = if (isError) DangerRed else MaterialTheme.colorScheme.primary,
            shape = RoundedCornerShape(12.dp),
            shadowElevation = 6.dp,
        ) {
            Text(
                text = message.orEmpty(),
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            )
        }
    }
}
