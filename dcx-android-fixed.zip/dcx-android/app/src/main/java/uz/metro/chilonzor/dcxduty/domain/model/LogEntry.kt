package uz.metro.chilonzor.dcxduty.domain.model

/** Запись системного лога/аудита (последние 300 записей). */
data class LogEntry(
    val id: String,
    val at: Long = System.currentTimeMillis(),
    val user: String = "",
    val action: String = "",
) {
    /** Форматированная дата-время для отображения в списке логов. */
    val atText: String
        get() = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss", java.util.Locale("ru"))
            .format(java.util.Date(at))
}
