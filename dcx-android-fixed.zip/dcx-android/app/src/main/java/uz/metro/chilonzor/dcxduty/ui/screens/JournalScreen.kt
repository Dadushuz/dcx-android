package uz.metro.chilonzor.dcxduty.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.Role
import uz.metro.chilonzor.dcxduty.ui.components.ConfirmDialog
import uz.metro.chilonzor.dcxduty.ui.components.EmptyState
import uz.metro.chilonzor.dcxduty.ui.components.StatusChip
import uz.metro.chilonzor.dcxduty.ui.components.ToastHost
import uz.metro.chilonzor.dcxduty.ui.fmtDateTime
import uz.metro.chilonzor.dcxduty.ui.theme.DangerRed
import uz.metro.chilonzor.dcxduty.ui.theme.MetroBlue
import uz.metro.chilonzor.dcxduty.ui.viewmodel.JournalTab
import uz.metro.chilonzor.dcxduty.ui.viewmodel.JournalViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.categoryTitle
import uz.metro.chilonzor.dcxduty.ui.viewmodel.title

/** Журнал приказов: вкладки «Все / На утверждении / Не внесены / Заготовки» + карточки действий. */
@Composable
fun JournalScreen(vm: JournalViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val toast by vm.toast.collectAsStateWithLifecycle()
    var cancelTarget by remember { mutableStateOf<Order?>(null) }
    var cancelReason by remember { mutableStateOf("") }

    LaunchedEffect(toast) {
        if (toast != null) { kotlinx.coroutines.delay(3_500); vm.clearToast() }
    }

    val role = s.user?.role

    Column(Modifier.fillMaxSize()) {
        // Вкладки с счётчиками
        LazyRow(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(JournalTab.entries, key = { it.name }) { tab ->
                val count = s.counts[tab] ?: 0
                FilterChip(
                    selected = s.tab == tab,
                    onClick = { vm.setTab(tab) },
                    label = { Text("${tab.title()} ($count)", style = MaterialTheme.typography.labelMedium) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MetroBlue, selectedLabelColor = Color.White,
                    ),
                )
            }
        }

        OutlinedTextField(
            value = s.search,
            onValueChange = vm::setSearch,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            singleLine = true,
            placeholder = { Text("Поиск: номер, тип, станция, сотрудник…") },
            leadingIcon = { Icon(Icons.Filled.Book, null, Modifier.size(20.dp)) },
            shape = RoundedCornerShape(10.dp),
        )

        Spacer(Modifier.height(10.dp))

        if (s.orders.isEmpty()) {
            EmptyState("По заданным фильтрам приказов не найдено.")
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(s.orders, key = { it.id }) { order ->
                    JournalCard(
                        order = order,
                        role = role,
                        onApprove = { vm.approve(order) },
                        onJournal = { vm.markInJournal(order) },
                        onCancel = { cancelTarget = order; cancelReason = "" },
                    )
                }
            }
        }
    }

    // Отмена приказа — с обязательным указанием причины.
    cancelTarget?.let { order ->
        AlertDialogWrapper(
            title = "Отмена приказа № ${order.number ?: "—"}",
            onDismiss = { cancelTarget = null },
            content = {
                Column {
                    Text("Отмена необратима и фиксируется в журнале аудита.",
                        style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = cancelReason,
                        onValueChange = { cancelReason = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Причина отмены *") },
                        minLines = 2,
                        shape = RoundedCornerShape(10.dp),
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            vm.cancel(order, cancelReason)
                            cancelTarget = null
                        },
                        enabled = cancelReason.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Подтвердить отмену") }
                }
            },
        )
    }

    ToastHost(message = toast?.first, isError = toast?.second ?: false,
        modifier = Modifier.padding(16.dp))
}

@Composable
private fun JournalCard(
    order: Order,
    role: Role?,
    onApprove: () -> Unit,
    onJournal: () -> Unit,
    onCancel: () -> Unit,
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(14.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("№ ${order.number ?: "—"}", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                StatusChip(order.status)
            }
            Spacer(Modifier.height(6.dp))
            Text(categoryTitle(order.category), style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold)
            Text(order.stationSummary(), style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${fmtDateTime(order.createdAt)} • ${order.shift.name}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            order.issuedByDch?.let {
                Text("ВЫДАЛ: $it", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (order.body.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Surface(color = Color(0xFF101418), shape = RoundedCornerShape(10.dp)) {
                    Text(order.body, color = Color(0xFFE8EDF3),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth().padding(10.dp))
                }
            }

            // ===== Действия =====
            val canApprove = role?.canApprove == true && order.status ==
                uz.metro.chilonzor.dcxduty.domain.model.OrderStatus.PENDING
            val canJournal = role?.canJournal == true && order.status ==
                uz.metro.chilonzor.dcxduty.domain.model.OrderStatus.ISSUED
            val canCancel = role?.canIssue == true && order.isCancelable

            if (canApprove || canJournal || canCancel) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (canApprove) {
                        Button(onClick = onApprove, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Check, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Утвердить", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                    if (canJournal) {
                        Button(onClick = onJournal, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Book, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("В журнал", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                    if (canCancel) {
                        OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Close, null, Modifier.size(18.dp), tint = DangerRed)
                            Spacer(Modifier.width(6.dp))
                            Text("Отменить", style = MaterialTheme.typography.labelLarge, color = DangerRed)
                        }
                    }
                }
                if (order.status == uz.metro.chilonzor.dcxduty.domain.model.OrderStatus.PENDING &&
                    role?.canApprove != true
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Ожидает утверждения старшего ДЦХ.",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

/** Минимальный диалог-обёртка (используется для ввода причины отмены). */
@Composable
fun AlertDialogWrapper(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit,
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        text = { content() },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } },
    )
}
