package uz.metro.chilonzor.dcxduty.di

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import uz.metro.chilonzor.dcxduty.data.local.DcxDatabase
import uz.metro.chilonzor.dcxduty.data.local.SessionStore
import uz.metro.chilonzor.dcxduty.data.remote.AuthRemoteDataSource
import uz.metro.chilonzor.dcxduty.data.remote.FirebaseConfig
import uz.metro.chilonzor.dcxduty.data.remote.NetworkMonitor
import uz.metro.chilonzor.dcxduty.data.remote.RemoteDatabaseSource
import uz.metro.chilonzor.dcxduty.data.repository.AuthRepositoryImpl
import uz.metro.chilonzor.dcxduty.data.repository.DutyRepositoryImpl
import uz.metro.chilonzor.dcxduty.data.repository.LogRepositoryImpl
import uz.metro.chilonzor.dcxduty.data.repository.OrderRepositoryImpl
import uz.metro.chilonzor.dcxduty.data.repository.TemplateRepositoryImpl

/**
 * Ручной DI-контейнер (без Hilt — чтобы сборка в Codespaces была максимально простой).
 * Создаётся один раз в DcxApp и живёт столько же, сколько процесс приложения.
 */
class AppContainer(private val context: Context) {

    val database: DcxDatabase by lazy { DcxDatabase.get(context) }
    val sessionStore: SessionStore by lazy { SessionStore(context) }
    val networkMonitor: NetworkMonitor by lazy { NetworkMonitor(context) }

    /** Инициализация Firebase SDK (если возможно) до создания источников данных. */
    val firebaseReady: Boolean = tryInitFirebase()

    val authRemote: AuthRemoteDataSource by lazy { AuthRemoteDataSource(context) }
    val remoteDb: RemoteDatabaseSource by lazy { RemoteDatabaseSource(context) }

    private val tokenProvider: suspend () -> String? = { sessionStore.token() }

    val authRepository: AuthRepositoryImpl by lazy {
        AuthRepositoryImpl(database, authRemote, remoteDb, sessionStore)
    }

    /** Провайдер имени текущего пользователя для логов (без блокировки корутин). */
    private val userNameProvider: suspend () -> String = {
        authRepository.currentSnapshot?.name ?: "—"
    }

    val orderRepository: OrderRepositoryImpl by lazy {
        OrderRepositoryImpl(database, remoteDb, tokenProvider, userNameProvider)
    }

    val dutyRepository: DutyRepositoryImpl by lazy {
        DutyRepositoryImpl(database, remoteDb, tokenProvider)
    }

    val templateRepository: TemplateRepositoryImpl by lazy {
        TemplateRepositoryImpl(database)
    }

    val logRepository: LogRepositoryImpl by lazy {
        LogRepositoryImpl(database, remoteDb, tokenProvider)
    }

    /**
     * Инициализирует Firebase SDK. Успех — если есть google-services.json (тогда FirebaseApp
     * создаётся автоматически) или заданы APP_ID/PROJECT_ID/API_KEY в FirebaseConfig.
     * Если не удалось — приложение работает через REST-резерв.
     */
    private fun tryInitFirebase(): Boolean {
        if (FirebaseApp.getApps(context).isNotEmpty()) return true
        if (FirebaseConfig.APP_ID.isBlank()) return false
        return runCatching {
            FirebaseApp.initializeApp(
                context,
                FirebaseOptions.Builder()
                    .setApplicationId(FirebaseConfig.APP_ID)
                    .setProjectId(FirebaseConfig.PROJECT_ID)
                    .setApiKey(FirebaseConfig.API_KEY)
                    .setDatabaseUrl(FirebaseConfig.DATABASE_URL)
                    .build(),
            ) != null
        }.getOrDefault(false)
    }
}
