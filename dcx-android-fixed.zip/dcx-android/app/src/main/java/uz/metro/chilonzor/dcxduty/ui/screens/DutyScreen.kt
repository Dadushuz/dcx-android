package uz.metro.chilonzor.dcxduty.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.Role
import uz.metro.chilonzor.dcxduty.ui.components.DcxTextField
import uz.metro.chilonzor.dcxduty.ui.components.EmptyState
import uz.metro.chilonzor.dcxduty.ui.components.SectionCard
import uz.metro.chilonzor.dcxduty.ui.components.StationDropdown
import uz.metro.chilonzor.dcxduty.ui.components.StatusChip
import uz.metro.chilonzor.dcxduty.ui.components.ToastHost
import uz.metro.chilonzor.dcxduty.ui.fmtDateTime
import uz.metro.chilonzor.dcxduty.ui.navigation.Routes
import uz.metro.chilonzor.dcxduty.ui.theme.MetroAccent
import uz.metro.chilonzor.dcxduty.ui.theme.MetroBlue
import uz.metro.chilonzor.dcxduty.ui.theme.StatusJournal
import uz.metro.chilonzor.dcxduty.ui.theme.StatusPending
import uz.metro.chilonzor.dcxduty.ui.viewmodel.DutyViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.categoryTitle

/** Экран дежурства: приём/сдача смены, сводка и последние приказы. */
@Composable
fun DutyScreen(vm: DutyViewModel, onNavigate: (String) -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    val toast by vm.toast.collectAsStateWithLifecycle()

    LaunchedEffect(toast) {
        if (toast != null) {
            kotlinx.coroutines.delay(3_500)
            vm.clearToast()
        }
    }

    val role = s.user?.role

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // ===== Шапка: кто на дежурстве =====
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MetroBlue),
                shape = RoundedCornerShape(16.dp),
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(if (s.meta.activeDch.isNotBlank()) "На дежурстве ДЦХ: ${s.meta.activeDch}"
                    else "Дежурный не назначен",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Следующий номер приказа: № ${s.meta.nextNumber}",
                        style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.85f))
                    if (s.meta.prevDch.isNotBlank()) {
                        Text("Сдал предыдущий: ${s.meta.prevDch}",
                            style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.75f))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(s.nowText, style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.75f))
                }
            }
        }

        if (s.shiftWindowOpen && role != Role.STATION) {
            item {
                Surface(color = MetroAccent, shape = RoundedCornerShape(12.dp)) {
                    Text("⏰ Окно пересменки (08:00 / 20:00) — оформите приём дежурства",
                        color = Color(0xFF3A2A00), style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth().padding(12.dp))
                }
            }
        }

        // ===== Приём дежурства =====
        if (role != Role.STATION) {
            item {
                SectionCard("Приём дежурства",
                    subtitle = "Подтвердите фамилию дежурного на новую смену") {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        DcxTextField(
                            value = s.acceptedNameInput,
                            onValueChange = vm::onAcceptedName,
                            label = "Дежурство принял(а) ДЦХ",
                            placeholder = "Фамилия И.",
                        )
                        Button(
                            onClick = { vm.acceptDuty() },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                        ) {
                            Icon(Icons.Filled.Check, null, Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Оформить приём смены", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }

            // ===== Приём и сдача дежурства =====
            item {
                SectionCard("Приём и сдача дежурства",
                    subtitle = "Оформление приказа передачи смены") {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        DcxTextField(
                            value = s.handoverOutgoingInput,
                            onValueChange = vm::onHandoverOutgoing,
                            label = "Дежурство сдал(а) ДЦХ",
                            placeholder = s.meta.activeDch.ifBlank { "Фамилия И." },
                        )
                        DcxTextField(
                            value = s.handoverIncomingInput,
                            onValueChange = vm::onHandoverIncoming,
                            label = "Дежурство принял(а) ДЦХ",
                            placeholder = "Фамилия И.",
                        )
                        Button(
                            onClick = { vm.handoverDuty() },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            enabled = s.handoverIncomingInput.length >= 3,
                        ) {
                            Icon(Icons.Filled.SwapHoriz, null, Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Оформить передачу дежурства", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }

        // ===== Сводка =====
        item {
            SectionCard("Сводка по приказам") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryTile("Всего", s.total, MetroBlue, Modifier.weight(1f))
                    SummaryTile("На утверждении", s.pending, StatusPending, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryTile("Не в журнале", s.notInJournal, StatusJournal, Modifier.weight(1f))
                    SummaryTile("Заготовки", s.drafts, Color(0xFF6B7280), Modifier.weight(1f))
                }
            }
        }

        // ===== Быстрые действия =====
        item {
            SectionCard("Быстрые действия") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { onNavigate(Routes.CREATE) },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                    ) { Text("➕ Выдать приказ / заготовка", style = MaterialTheme.typography.titleMedium) }
                    Button(
                        onClick = { onNavigate(Routes.JOURNAL) },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                    ) { Text("📖 Журнал приказов", style = MaterialTheme.typography.titleMedium) }
                }
            }
        }

        // ===== Последние приказы =====
        item {
            Text("Последние приказы", style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold)
        }
        if (s.lastOrders.isEmpty()) {
            item { EmptyState("Приказов пока нет. Оформите первый приказ в разделе «Приказ».") }
        } else {
            items(s.lastOrders, key = { it.id }) { order -> DutyOrderRow(order) }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }

    ToastHost(
        message = toast?.first,
        isError = toast?.second ?: false,
        modifier = Modifier.padding(16.dp),
    )
}

@Composable
private fun SummaryTile(label: String, value: Int, color: Color, modifier: Modifier = Modifier) {
    Surface(modifier, color = color.copy(alpha = 0.10f), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text("$value", style = MaterialTheme.typography.headlineSmall,
                color = color, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DutyOrderRow(order: Order) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(14.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("№ ${order.number ?: "—"}", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                StatusChip(order.status)
            }
            Spacer(Modifier.height(6.dp))
            Text(categoryTitle(order.category), style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold)
            Text(order.stationSummary(), style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(fmtDateTime(order.createdAt), style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
