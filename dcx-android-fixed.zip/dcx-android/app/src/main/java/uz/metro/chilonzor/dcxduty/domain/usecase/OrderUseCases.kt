package uz.metro.chilonzor.dcxduty.domain.usecase

import uz.metro.chilonzor.dcxduty.domain.model.DefaultTemplates
import uz.metro.chilonzor.dcxduty.domain.model.FieldError
import uz.metro.chilonzor.dcxduty.domain.model.FieldKeys
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.OrderCategory
import uz.metro.chilonzor.dcxduty.domain.model.Stations
import uz.metro.chilonzor.dcxduty.domain.model.ValidationResult

/**
 * Строгая валидация формы приказа (перенесена и усилена относительно web-версии).
 * Проверяет: обязательные поля, формат времени, номер поезда, выбор путей и станций.
 *
 * @param requiredLabels отображаемые названия полей — подставляются в сообщение об ошибке.
 */
class ValidateOrderUseCase(
    private val requiredLabels: Map<String, String> = emptyMap(),
) {
    operator fun invoke(
        category: OrderCategory,
        fields: Map<String, String>,
        dutyAcceptedAtTime: String? = null,
    ): ValidationResult {
        val errors = mutableListOf<FieldError>()

        fun req(key: String) {
            if (fields[key].isNullOrBlank()) {
                errors += FieldError(key, "err_required:${requiredLabels[key] ?: key}")
            }
        }

        // 1. Время выдачи — обязательное и в формате ЧЧ:ММ
        val time = fields[FieldKeys.TIME].orEmpty().trim()
        when {
            time.isBlank() -> errors += FieldError(FieldKeys.TIME, "err_required:Время выдачи")
            !isValidTime(time) -> errors += FieldError(FieldKeys.TIME, "err_time_format")
            dutyAcceptedAtTime != null && !time.isBlank() && isValidTime(dutyAcceptedAtTime) &&
                toMinutes(time) < toMinutes(dutyAcceptedAtTime) ->
                errors += FieldError(FieldKeys.TIME, "err_time_order")
        }

        // 2. Проверки по типу приказа
        when (category) {
            OrderCategory.SHIFT_HANDOVER -> {
                req(FieldKeys.ACCEPTED_BY)
                req(FieldKeys.HANDED_BY)
            }

            OrderCategory.HOZ_WRONG_DIR -> {
                validateTrainNumber(fields[FieldKeys.HOZ_TRAIN], FieldKeys.HOZ_TRAIN, errors)
                req(FieldKeys.HOZ_TRACK_FROM)
                req(FieldKeys.HOZ_TRACK_TO)
                if (fields[FieldKeys.HOZ_TRACK_FROM] == fields[FieldKeys.HOZ_TRACK_TO] &&
                    fields[FieldKeys.HOZ_TRACK_FROM] != null
                ) {
                    errors += FieldError(FieldKeys.HOZ_TRACK_TO, "err_track_required")
                }
                // Отправление: либо станция, либо перегон
                val depType = fields[FieldKeys.HOZ_DEP_TYPE]
                if (depType == "station") req(FieldKeys.HOZ_DEP_STATION)
                if (depType == "span") req(FieldKeys.HOZ_DEP_SPAN)
                req(FieldKeys.HOZ_DEST_STATION)
                if (fields[FieldKeys.HOZ_TRAIN] != null &&
                    fields[FieldKeys.HOZ_TRAIN] == fields[FieldKeys.HOZ_OTHER_TRAIN]
                ) {
                    errors += FieldError(FieldKeys.HOZ_OTHER_TRAIN, "err_train_blank")
                }
                if (!fields[FieldKeys.HOZ_OTHER_TRAIN].isNullOrBlank() &&
                    !isValidTrainNumber(fields[FieldKeys.HOZ_OTHER_TRAIN]!!)
                ) {
                    errors += FieldError(FieldKeys.HOZ_OTHER_TRAIN, "err_train_number")
                }
                if (fields[FieldKeys.HOZ_DEP_STATION] != null && fields[FieldKeys.HOZ_DEST_STATION] != null &&
                    fields[FieldKeys.HOZ_DEP_STATION] == fields[FieldKeys.HOZ_DEST_STATION]
                ) {
                    errors += FieldError(FieldKeys.HOZ_DEST_STATION, "err_station_same")
                }
            }

            OrderCategory.AB_TO_ALS, OrderCategory.ALS_TO_AB,
            OrderCategory.ENERGY_DCH, OrderCategory.VOLTAGE_OFF,
            OrderCategory.TRACK_CLOSE -> {
                req(FieldKeys.TECH_TRACK)
                req(FieldKeys.TECH_SECTION)
            }
        }

        // 3. Валидация станций (если заданы)
        fields[FieldKeys.FROM_STATION]?.takeIf { it.isNotBlank() }?.let {
            if (Stations.byCode(it) == null) errors += FieldError(FieldKeys.FROM_STATION, "err_station_required")
        }
        fields[FieldKeys.TO_STATION]?.takeIf { it.isNotBlank() }?.let {
            if (Stations.byCode(it) == null) errors += FieldError(FieldKeys.TO_STATION, "err_station_required")
        }

        return if (errors.isEmpty()) ValidationResult.Valid else ValidationResult.Invalid(errors)
    }

    private fun validateTrainNumber(value: String?, key: String, errors: MutableList<FieldError>) {
        if (value.isNullOrBlank()) {
            errors += FieldError(key, "err_train_blank")
        } else if (!isValidTrainNumber(value)) {
            errors += FieldError(key, "err_train_number")
        }
    }

    companion object {
        private val TIME_RE = Regex("^([01]\\d|2[0-3]):[0-5]\\d$")
        private val TRAIN_RE = Regex("^\\d{3,6}$")

        fun isValidTime(value: String): Boolean = TIME_RE.matches(value.trim())
        fun isValidTrainNumber(value: String): Boolean = TRAIN_RE.matches(value.trim())
        fun toMinutes(value: String): Int {
            val (h, m) = value.split(":").map { it.toIntOrNull() ?: 0 }
            return h * 60 + m
        }
    }
}

/**
 * Сборка текста штампа приказа из подшаблона и подстановок.
 * Плейсхолдеры: {путь}, {участок}, {доп}.
 */
class ComposeOrderTextUseCase {
    operator fun invoke(
        templateText: String,
        track: String? = null,
        section: String? = null,
        extra: String? = null,
    ): String = templateText
        .replace("{путь}", track.orEmpty())
        .replace("{участок}", section.orEmpty())
        .replace("{доп}", extra.orEmpty())
        .replace(Regex("\\s{2,}"), " ")
        .trim()

    /** Выбирает текст подшаблона по категории и id. */
    fun templateText(category: OrderCategory, subId: String?): String {
        val list = DefaultTemplates.items.filter { it.category == category }
        return (subId?.let { id -> list.firstOrNull { it.id == id } } ?: list.firstOrNull())?.textTemplate.orEmpty()
    }
}

/** Фильтрация приказов для раздела "Отчёты". */
class FilterOrdersUseCase {
    operator fun invoke(orders: List<Order>, filter: uz.metro.chilonzor.dcxduty.domain.model.ReportFilter): List<Order> =
        orders.filter { o ->
            (filter.shift == uz.metro.chilonzor.dcxduty.domain.model.Shift.NONE || o.shift == filter.shift) &&
                (filter.stationCode == null || o.targetStationCodes.contains(filter.stationCode) ||
                    o.fromStationCode == filter.stationCode || o.toStationCode == filter.stationCode ||
                    o.allStations) &&
                (filter.category == null || o.category == filter.category) &&
                (filter.employee == null || o.issuedByDch == filter.employee) &&
                (filter.dateFrom == null || o.createdAt >= filter.dateFrom) &&
                (filter.dateTo == null || o.createdAt <= filter.dateTo)
        }
}
