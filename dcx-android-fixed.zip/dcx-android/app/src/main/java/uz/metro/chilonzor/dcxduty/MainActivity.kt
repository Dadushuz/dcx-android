package uz.metro.chilonzor.dcxduty

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import uz.metro.chilonzor.dcxduty.di.AppContainer
import uz.metro.chilonzor.dcxduty.ui.screens.LoginScreen
import uz.metro.chilonzor.dcxduty.ui.screens.MainScreen
import uz.metro.chilonzor.dcxduty.ui.theme.DcxTheme
import uz.metro.chilonzor.dcxduty.ui.viewmodel.DcxViewModelFactory
import uz.metro.chilonzor.dcxduty.ui.viewmodel.LoginViewModel

/**
 * Единственная Activity приложения (single-activity + Compose Navigation).
 *
 * Экран определяется сессией из AuthRepository: пока пользователь не вошёл (или после выхода),
 * показывается LoginScreen; при активной сессии — основной каркас с нижней навигацией.
 * Такой подход автоматически возвращает на экран входа после выхода из системы.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as DcxApp).container
        val factory = DcxViewModelFactory(container)
        setContent {
            DcxTheme {
                DcxRoot(container = container, factory = factory)
            }
        }
    }
}

@Composable
private fun DcxRoot(container: AppContainer, factory: DcxViewModelFactory) {
    val loginVm: LoginViewModel = viewModel(factory = factory)

    // Источник правды — сессия пользователя (восстанавливается в DcxApp.onCreate).
    val user by container.authRepository.currentUser.collectAsStateWithLifecycle(initialValue = null)

    if (user == null) {
        LoginScreen(vm = loginVm, onLoggedIn = { /* состояние обновится из currentUser */ })
    } else {
        MainScreen(
            container = container,
            factory = factory,
            onLoggedOut = { /* состояние обновится из currentUser */ },
        )
    }
}
