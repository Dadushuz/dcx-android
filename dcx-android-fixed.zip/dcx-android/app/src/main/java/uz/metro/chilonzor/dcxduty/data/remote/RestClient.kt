package uz.metro.chilonzor.dcxduty.data.remote

import android.util.Log
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

/** Простой HTTP-JSON клиент для резервного (REST) режима Firebase. */
object RestClient {
    private const val TAG = "DcxRest"
    private val gson = Gson()

    suspend fun request(url: String, method: String = "GET", body: String? = null): String? =
        withContext(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 15_000
                    readTimeout = 15_000
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    doInput = true
                    if (body != null) doOutput = true
                }
                body?.let { conn.outputStream.use { os -> os.write(it.toByteArray(Charsets.UTF_8)) } }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text: String? = stream?.bufferedReader()?.use(BufferedReader::readText)
                if (code !in 200..299) {
                    Log.w(TAG, "HTTP $code: $text")
                    return@withContext null
                }
                text
            } catch (t: Throwable) {
                Log.w(TAG, "Ошибка сети: ${t.message}")
                null
            } finally {
                conn?.disconnect()
            }
        }

    fun <T> fromJson(json: String?, clazz: Class<T>): T? =
        runCatching { gson.fromJson(json, clazz) }.getOrNull()

    fun toJson(value: Any): String = gson.toJson(value)
}
