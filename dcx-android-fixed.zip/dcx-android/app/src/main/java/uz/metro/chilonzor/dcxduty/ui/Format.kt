package uz.metro.chilonzor.dcxduty.ui

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ru = Locale("ru")

/** Форматирование даты и времени для списков (единый формат по всему приложению). */
fun fmtDateTime(ts: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm", ru).format(Date(ts))
fun fmtDate(ts: Long): String = SimpleDateFormat("dd.MM.yyyy", ru).format(Date(ts))
fun fmtTime(ts: Long): String = SimpleDateFormat("HH:mm", ru).format(Date(ts))
fun fmtTimeSeconds(ts: Long): String = SimpleDateFormat("dd.MM HH:mm:ss", ru).format(Date(ts))
