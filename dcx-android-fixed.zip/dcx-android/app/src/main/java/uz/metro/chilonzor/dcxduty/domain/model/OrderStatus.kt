package uz.metro.chilonzor.dcxduty.domain.model

/**
 * Жизненный цикл приказа:
 * ЧЕРНОВИК -> НА УТВЕРЖДЕНИИ -> ВЫДАН -> ВНЕСЁН В ЖУРНАЛ
 * (ОТМЕНЁН — из любого состояния, кроме "ВНЕСЁН В ЖУРНАЛ").
 */
enum class OrderStatus {
    DRAFT,     // ЧЕРНОВИК
    PENDING,   // НА УТВЕРЖДЕНИИ
    ISSUED,    // ВЫДАН
    JOURNAL,   // ВНЕСЁН В ЖУРНАЛ
    CANCELED;  // ОТМЕНЁН

    /** Порядковый номер шага для отрисовки прогресса. */
    val step: Int
        get() = when (this) {
            DRAFT -> 0
            PENDING -> 1
            ISSUED -> 2
            JOURNAL -> 3
            CANCELED -> -1
        }

    companion object {
        /**
         * Вычисляет статус по полям заказа.
         * Логика 1:1 перенесена из web-версии (statusOf).
         */
        fun of(order: Order): OrderStatus = when {
            order.canceled -> CANCELED
            order.draft -> DRAFT
            order.approvedAt == null -> PENDING
            !order.inPaperJournal -> ISSUED
            else -> JOURNAL
        }
    }
}
