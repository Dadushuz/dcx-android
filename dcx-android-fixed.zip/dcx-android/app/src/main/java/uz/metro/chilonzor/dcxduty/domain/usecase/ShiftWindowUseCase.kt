package uz.metro.chilonzor.dcxduty.domain.usecase

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Проверка окна пересменки: 07:45–08:30 и 19:45–20:30. */
class ShiftWindowUseCase {
    operator fun invoke(now: Long = System.currentTimeMillis()): Boolean {
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = now
        val m = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        return (m in 465..510) || (m in 1185..1230)
    }

    /** Текст подсказки о времени пересменки. */
    fun text(now: Long = System.currentTimeMillis()): String =
        "Время пересменки (08:00 / 20:00). Текущее время: ${time(now)}"

    fun time(now: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("HH:mm", Locale("ru")).format(Date(now))

    fun dateTime(now: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru")).format(Date(now))
}
