package uz.metro.chilonzor.dcxduty.domain.repository

import kotlinx.coroutines.flow.Flow
import uz.metro.chilonzor.dcxduty.domain.model.DutyMeta
import uz.metro.chilonzor.dcxduty.domain.model.LogEntry
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.OrderTemplate
import uz.metro.chilonzor.dcxduty.domain.model.SyncState
import uz.metro.chilonzor.dcxduty.domain.model.UserProfile

/** Репозиторий приказов: единый источник правды для UI (Room) + фоновая синхронизация (Firebase). */
interface OrderRepository {
    fun observeAll(): Flow<List<Order>>
    fun observePending(): Flow<List<Order>>
    fun observeNotInPaperJournal(): Flow<List<Order>>
    fun observeDrafts(): Flow<List<Order>>
    suspend fun byId(id: String): Order?

    /** Сохраняет приказ локально и ставит в очередь на синхронизацию. */
    suspend fun upsert(order: Order): Order

    /** Выдаёт черновик/заготовку: присваивает номер, статус PENDING или ISSUED. */
    suspend fun issue(orderId: String, issuedAt: String, requireApproval: Boolean): Order

    /** Утверждает приказ (старший ДЦХ). */
    suspend fun approve(orderId: String, approverName: String): Order

    /** Помечает приказ как внесённый в бумажный журнал. */
    suspend fun markInPaperJournal(orderId: String): Order

    /** Отменяет приказ с указанием причины. */
    suspend fun cancel(orderId: String, reason: String): Order

    /** Резервирует следующий номер приказа. */
    suspend fun reserveNumber(): Int

    /** Текущее значение следующего номера. */
    suspend fun peekNextNumber(): Int

    /** Принудительно задаёт следующий номер (панель основателя). */
    suspend fun setNextNumber(number: Int)

    /** Удаляет утверждённые приказы старше [days] дней. */
    suspend fun cleanupApprovedOlderThan(days: Int): Int

    fun observeSyncState(): Flow<SyncState>
    fun observePendingCount(): Flow<Int>

    /** Немедленная синхронизация (кнопка "Синхронизировать"). */
    suspend fun syncNow(): Int
}

/** Репозиторий дежурств и метаданных. */
interface DutyRepository {
    fun observeMeta(): Flow<DutyMeta>
    suspend fun acceptDuty(dchName: String, at: Long = System.currentTimeMillis())
    suspend fun handoverDuty(incomingName: String, outgoingName: String, at: Long = System.currentTimeMillis())
}

/** Репозиторий шаблонов (заготовок). */
interface TemplateRepository {
    fun observeAll(): Flow<List<OrderTemplate>>
    suspend fun save(template: OrderTemplate)
    suspend fun remove(id: String)
}

/** Репозиторий системных логов. */
interface LogRepository {
    fun observeRecent(limit: Int = 300): Flow<List<LogEntry>>
    suspend fun log(action: String, user: String, at: Long = System.currentTimeMillis())
    suspend fun clear()
}

/** Репозиторий аутентификации и пользователей. */
interface AuthRepository {
    val currentUser: Flow<UserProfile?>
    suspend fun signIn(email: String, password: String): Result<UserProfile>
    suspend fun signOut(): Result<Unit>
    suspend fun createAccount(email: String, password: String, profile: UserProfile): Result<UserProfile>
    suspend fun listAccounts(): List<UserProfile>
}
