package uz.metro.chilonzor.dcxduty.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import uz.metro.chilonzor.dcxduty.DcxApp
import java.util.concurrent.TimeUnit

/**
 * Фоновая синхронизация "грязных" приказов с Firebase.
 * Запускается периодически (каждые 15 минут) и по требованию при появлении сети.
 */
class SyncWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as DcxApp).container
        return try {
            val sent = container.orderRepository.syncNow()
            Result.success(workDataOf(sent))
        } catch (t: Throwable) {
            // Сеть пропала — WorkManager повторит попытку позже.
            Result.retry()
        }
    }

    private fun workDataOf(sent: Int) = androidx.work.workDataOf(KEY_SENT to sent)

    companion object {
        const val KEY_SENT = "sent"
        private const val PERIODIC_NAME = "dcx_sync_periodic"
        private const val ONCE_NAME = "dcx_sync_once"

        /** Периодическая задача: только при наличии сети. */
        fun schedulePeriodic(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                PERIODIC_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request,
            )
        }

        /** Немедленная синхронизация (например, после восстановления связи). */
        fun syncNow(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
