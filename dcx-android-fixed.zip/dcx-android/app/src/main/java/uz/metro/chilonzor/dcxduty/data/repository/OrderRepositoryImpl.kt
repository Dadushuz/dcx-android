package uz.metro.chilonzor.dcxduty.data.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import uz.metro.chilonzor.dcxduty.data.local.DcxDatabase
import uz.metro.chilonzor.dcxduty.data.local.entity.MetaEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.OrderEntity
import uz.metro.chilonzor.dcxduty.data.local.entity.toDomain
import uz.metro.chilonzor.dcxduty.data.local.entity.toEntity
import uz.metro.chilonzor.dcxduty.data.remote.FirebaseConfig
import uz.metro.chilonzor.dcxduty.data.remote.RemoteDatabaseSource
import uz.metro.chilonzor.dcxduty.data.remote.dto.LogDto
import uz.metro.chilonzor.dcxduty.data.remote.dto.OrderDto
import uz.metro.chilonzor.dcxduty.domain.model.LogEntry
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.SyncState
import uz.metro.chilonzor.dcxduty.domain.repository.OrderRepository
import java.util.UUID

/**
 * Offline-first репозиторий приказов.
 *
 * Запись всегда идёт в Room (мгновенно видно в UI), затем помечается dirty = true.
 * Синхронизация отправляет "грязные" записи в Firebase; при отсутствии сети данные
 * остаются в очереди и отправляются позже (SyncWorker / кнопка "Синхронизировать").
 */
class OrderRepositoryImpl(
    private val db: DcxDatabase,
    private val remote: RemoteDatabaseSource,
    private val tokenProvider: suspend () -> String?,
    private val userNameProvider: suspend () -> String,
) : OrderRepository {

    private val syncState = MutableStateFlow(SyncState.SYNCED)

    override fun observeAll(): Flow<List<Order>> =
        db.orderDao().observeAll().map { list -> list.map { it.toDomain() } }

    override fun observePending(): Flow<List<Order>> =
        db.orderDao().observePending().map { list -> list.map { it.toDomain() } }

    override fun observeNotInPaperJournal(): Flow<List<Order>> =
        db.orderDao().observeNotInPaperJournal().map { list -> list.map { it.toDomain() } }

    override fun observeDrafts(): Flow<List<Order>> =
        db.orderDao().observeDrafts().map { list -> list.map { it.toDomain() } }

    override suspend fun byId(id: String): Order? = db.orderDao().byId(id)?.toDomain()

    override suspend fun upsert(order: Order): Order {
        val stamped = order.copy(updatedAt = System.currentTimeMillis(), dirty = true)
        db.orderDao().upsert(stamped.toEntity())
        writeMetaIfNeeded()
        return stamped
    }

    override suspend fun issue(orderId: String, issuedAt: String, requireApproval: Boolean): Order {
        val current = requireNotNull(byId(orderId)) { "Приказ не найден" }
        val number = current.number ?: reserveNumber()
        val updated = current.copy(
            number = number,
            draft = false,
            issuedAt = issuedAt,
            approvedAt = if (requireApproval) null else System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            dirty = true,
        )
        db.orderDao().upsert(updated.toEntity())
        writeMetaIfNeeded()
        return updated
    }

    override suspend fun approve(orderId: String, approverName: String): Order {
        val current = requireNotNull(byId(orderId)) { "Приказ не найден" }
        val updated = current.copy(
            approvedAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            dirty = true,
        )
        db.orderDao().upsert(updated.toEntity())
        log("Утвердил(а) приказ № ${updated.number ?: "—"} — $approverName")
        return updated
    }

    override suspend fun markInPaperJournal(orderId: String): Order {
        val current = requireNotNull(byId(orderId)) { "Приказ не найден" }
        val updated = current.copy(inPaperJournal = true, updatedAt = System.currentTimeMillis(), dirty = true)
        db.orderDao().upsert(updated.toEntity())
        log("Внёс(ла) в бумажный журнал приказ № ${updated.number ?: "—"}")
        return updated
    }

    override suspend fun cancel(orderId: String, reason: String): Order {
        val current = requireNotNull(byId(orderId)) { "Приказ не найден" }
        val updated = current.copy(
            canceled = true,
            updatedAt = System.currentTimeMillis(),
            body = current.body,
            fields = current.fields + mapOf("cancelReason" to reason),
            dirty = true,
        )
        db.orderDao().upsert(updated.toEntity())
        log("Отменил(а) приказ № ${updated.number ?: "—"}: $reason")
        return updated
    }

    override suspend fun reserveNumber(): Int {
        val stored = db.metaDao().get(KEY_NEXT)?.toIntOrNull()
        val fromMax = (db.orderDao().maxNumber() ?: 0) + 1
        val next = maxOf(stored ?: 1, fromMax)
        db.metaDao().put(MetaEntity(KEY_NEXT, (next + 1).toString()))
        return next
    }

    override suspend fun peekNextNumber(): Int {
        val stored = db.metaDao().get(KEY_NEXT)?.toIntOrNull()
        val fromMax = (db.orderDao().maxNumber() ?: 0) + 1
        return maxOf(stored ?: 1, fromMax)
    }

    override suspend fun setNextNumber(number: Int) {
        db.metaDao().put(MetaEntity(KEY_NEXT, number.toString()))
        log("Задал(а) следующий номер приказа: № $number")
    }

    override suspend fun cleanupApprovedOlderThan(days: Int): Int {
        val before = System.currentTimeMillis() - days * 24L * 3600L * 1000L
        val removed = db.orderDao().deleteApprovedBefore(before)
        log("Очищено утверждённых приказов старше $days дн.: $removed")
        return removed
    }

    override fun observeSyncState(): Flow<SyncState> = syncState.asStateFlow()

    override fun observePendingCount(): Flow<Int> = db.orderDao().observeDirtyCount()

    /** Отправляет все "грязные" записи в Firebase. Возвращает число отправленных. */
    override suspend fun syncNow(): Int {
        val dirty = db.orderDao().dirty()
        if (dirty.isEmpty()) {
            syncState.value = SyncState.SYNCED
            return 0
        }
        syncState.value = SyncState.PENDING
        val token = tokenProvider()
        var sent = 0
        for (entity in dirty) {
            val dto = entity.toDomain().toDto()
            val ok = if (remote.isSdkReady) remote.pushOrderSdk(dto) else remote.pushOrderRest(dto, token)
            if (ok) {
                db.orderDao().upsert(entity.copy(dirty = false))
                sent++
            }
        }
        syncState.value = if (sent == dirty.size) SyncState.SYNCED else SyncState.ERROR
        return sent
    }

    /** Подтягивает приказы из Firebase (первичная загрузка / обновление). */
    suspend fun pullFromRemote(): Int {
        val remoteOrders = if (remote.isSdkReady) remote.fetchOrdersSdk()
        else remote.fetchOrdersRest(tokenProvider())
        if (remoteOrders.isEmpty()) return 0
        val existing = db.orderDao().observeAll()
        val local = db.orderDao().dirty()
        val localIds = local.map { it.id }.toSet()
        val toSave = remoteOrders
            .filter { it.id.isNotBlank() && it.id !in localIds }
            .map { it.toEntity() }
        db.orderDao().upsertAll(toSave)
        return toSave.size
    }

    private suspend fun writeMetaIfNeeded() {
        val next = peekNextNumber()
        val name = userNameProvider()
        db.metaDao().put(MetaEntity(KEY_ACTIVE_DCH, name))
        db.metaDao().put(MetaEntity(KEY_NEXT, next.toString()))
    }

    private suspend fun log(action: String) {
        val entry = LogEntry(id = UUID.randomUUID().toString(), user = userNameProvider(), action = action)
        db.logDao().insert(uz.metro.chilonzor.dcxduty.data.local.entity.LogEntity(
            id = entry.id, at = entry.at, user = entry.user, action = entry.action
        ))
        db.logDao().trimTo300()
        // В Firebase лог уходит "best effort", чтобы не блокировать работу пользователя.
        val dto = LogDto().apply { id = entry.id; at = entry.at; user = entry.user; this.action = entry.action }
        runCatching {
            if (remote.isSdkReady) remote.pushLogSdk(dto) else remote.pushLogRest(dto, tokenProvider())
        }
    }

    private fun Order.toDto(): OrderDto = OrderDto().apply {
        id = this@toDto.id
        number = this@toDto.number
        cat = category.code
        draft = this@toDto.draft
        canceled = this@toDto.canceled
        utvAt = approvedAt
        paper = inPaperJournal
        at = createdAt
        upd = updatedAt
        time = issuedAt
        from = fromStationCode
        to = toStationCode
        allSt = allStations
        targets = targetStationCodes
        shift = this@toDto.shift.name
        byDch = issuedByDch
        accepted = acceptedByDch
        handed = handedByDch
        body = this@toDto.body
        fields = this@toDto.fields
    }

    private fun OrderDto.toEntity() = OrderEntity(
        id = id,
        number = number,
        categoryCode = cat,
        draft = draft,
        canceled = canceled,
        approvedAt = utvAt,
        inPaperJournal = paper,
        createdAt = if (at > 0) at else System.currentTimeMillis(),
        updatedAt = if (upd > 0) upd else System.currentTimeMillis(),
        issuedAt = time,
        fromStationCode = from,
        toStationCode = to,
        allStations = allSt,
        targetStationCodes = targets,
        shiftName = shift,
        issuedByDch = byDch,
        acceptedByDch = accepted,
        handedByDch = handed,
        body = body,
        fields = fields.mapValues { it.value?.toString() ?: "" },
        dirty = false,
        deleted = false,
    )

    companion object {
        const val KEY_NEXT = "next_number"
        const val KEY_ACTIVE_DCH = "active_dch"
        const val KEY_PREV_DCH = "prev_dch"
    }
}
