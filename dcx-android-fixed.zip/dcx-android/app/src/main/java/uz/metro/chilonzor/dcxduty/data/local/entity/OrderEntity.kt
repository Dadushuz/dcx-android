package uz.metro.chilonzor.dcxduty.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.OrderCategory
import uz.metro.chilonzor.dcxduty.domain.model.Shift

/** Локальная запись приказа (Room). Списки хранятся через конвертеры. */
@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val number: Int?,
    val categoryCode: String,
    val draft: Boolean,
    val canceled: Boolean,
    val approvedAt: Long?,
    val inPaperJournal: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val issuedAt: String?,
    val fromStationCode: String?,
    val toStationCode: String?,
    val allStations: Boolean,
    val targetStationCodes: List<String>,
    val shiftName: String,
    val issuedByDch: String?,
    val acceptedByDch: String?,
    val handedByDch: String?,
    val body: String,
    val fields: Map<String, String>,
    val dirty: Boolean,
    val deleted: Boolean,
)

fun OrderEntity.toDomain(): Order = Order(
    id = id,
    number = number,
    category = OrderCategory.fromCode(categoryCode) ?: OrderCategory.SHIFT_HANDOVER,
    draft = draft,
    canceled = canceled,
    approvedAt = approvedAt,
    inPaperJournal = inPaperJournal,
    createdAt = createdAt,
    updatedAt = updatedAt,
    issuedAt = issuedAt,
    fromStationCode = fromStationCode,
    toStationCode = toStationCode,
    allStations = allStations,
    targetStationCodes = targetStationCodes,
    shift = runCatching { Shift.valueOf(shiftName) }.getOrDefault(Shift.NONE),
    issuedByDch = issuedByDch,
    acceptedByDch = acceptedByDch,
    handedByDch = handedByDch,
    body = body,
    fields = fields,
    dirty = dirty,
    deleted = deleted,
)

fun Order.toEntity(): OrderEntity = OrderEntity(
    id = id,
    number = number,
    categoryCode = category.code,
    draft = draft,
    canceled = canceled,
    approvedAt = approvedAt,
    inPaperJournal = inPaperJournal,
    createdAt = createdAt,
    updatedAt = updatedAt,
    issuedAt = issuedAt,
    fromStationCode = fromStationCode,
    toStationCode = toStationCode,
    allStations = allStations,
    targetStationCodes = targetStationCodes,
    shiftName = shift.name,
    issuedByDch = issuedByDch,
    acceptedByDch = acceptedByDch,
    handedByDch = handedByDch,
    body = body,
    fields = fields,
    dirty = dirty,
    deleted = deleted,
)
