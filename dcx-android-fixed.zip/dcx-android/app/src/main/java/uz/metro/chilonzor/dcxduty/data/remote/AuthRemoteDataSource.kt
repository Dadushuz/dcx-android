package uz.metro.chilonzor.dcxduty.data.remote

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.tasks.await
import uz.metro.chilonzor.dcxduty.data.remote.dto.AuthResponseDto
import uz.metro.chilonzor.dcxduty.data.remote.dto.ErrorEnvelopeDto

/** Текущая сессия: uid + токен (токен нужен в резервном REST-режиме). */
data class AuthSession(val uid: String, val email: String, val idToken: String?)

/** Причина ошибки входа — для показа точного сообщения на русском. */
enum class AuthError { INVALID_CREDENTIALS, NETWORK, NOT_CONFIGURED, UNKNOWN }

class AuthException(val reason: AuthError, message: String? = null) : Exception(message)

/**
 * Источник данных аутентификации: Firebase Auth SDK (основной) + Identity Toolkit REST (резерв).
 */
class AuthRemoteDataSource(private val context: Context) {

    private val sdk: FirebaseAuth?
        get() = if (FirebaseApp.getApps(context).isNotEmpty()) FirebaseAuth.getInstance() else null

    val sdkReady: Boolean get() = sdk != null

    /** Вход: сначала пробуем SDK, затем REST. */
    suspend fun signIn(email: String, password: String): AuthSession {
        sdk?.let { auth ->
            try {
                val res = auth.signInWithEmailAndPassword(email, password).await()
                val user = res.user ?: throw AuthException(AuthError.UNKNOWN)
                val token = user.getIdToken(false).await()?.token
                return AuthSession(user.uid, user.email ?: email, token)
            } catch (e: AuthException) {
                throw e
            } catch (t: Throwable) {
                Log.w("DcxAuth", "SDK signIn не удался, пробуем REST: ${t.message}")
            }
        }
        return signInRest(email, password)
    }

    private suspend fun signInRest(email: String, password: String): AuthSession {
        val url = "${FirebaseConfig.IDENTITY_BASE}/accounts:signInWithPassword?key=${FirebaseConfig.API_KEY}"
        val body = RestClient.toJson(mapOf(
            "email" to email,
            "password" to password,
            "returnSecureToken" to true,
        ))
        val raw = RestClient.request(url, "POST", body)
            ?: throw AuthException(AuthError.NETWORK)
        val dto = RestClient.fromJson(raw, AuthResponseDto::class.java)
        if (dto?.localId.isNullOrBlank()) {
            val err = RestClient.fromJson(raw, ErrorEnvelopeDto::class.java)
            val message = err?.error?.message.orEmpty()
            throw AuthException(
                when {
                    message.contains("INVALID_LOGIN_CREDENTIALS", true) ||
                        message.contains("EMAIL_NOT_FOUND", true) ||
                        message.contains("INVALID_PASSWORD", true) -> AuthError.INVALID_CREDENTIALS
                    message.contains("API_KEY_INVALID", true) -> AuthError.NOT_CONFIGURED
                    else -> AuthError.UNKNOWN
                },
                message,
            )
        }
        return AuthSession(dto.localId!!, dto.email ?: email, dto.idToken)
    }

    /**
     * Создание аккаунта сотрудника (панель основателя).
     * ВСЕГДА через REST: SDK-создание пользователя разорвало бы текущую сессию основателя.
     */
    suspend fun createAccount(email: String, password: String): String {
        val url = "${FirebaseConfig.IDENTITY_BASE}/accounts:signUp?key=${FirebaseConfig.API_KEY}"
        val body = RestClient.toJson(mapOf(
            "email" to email,
            "password" to password,
            "returnSecureToken" to true,
        ))
        val raw = RestClient.request(url, "POST", body) ?: throw AuthException(AuthError.NETWORK)
        val dto = RestClient.fromJson(raw, AuthResponseDto::class.java)
        if (dto?.localId.isNullOrBlank()) {
            val err = RestClient.fromJson(raw, ErrorEnvelopeDto::class.java)
            throw AuthException(AuthError.UNKNOWN, err?.error?.message)
        }
        return dto.localId!!
    }

    suspend fun signOut() {
        try {
            sdk?.signOut()
        } catch (t: Throwable) {
            Log.w("DcxAuth", "Ошибка signOut SDK: ${t.message}")
        }
    }
}
