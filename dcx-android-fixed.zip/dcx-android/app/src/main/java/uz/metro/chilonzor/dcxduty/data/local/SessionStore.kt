package uz.metro.chilonzor.dcxduty.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "dcx_session")

/**
 * Хранилище сессии (DataStore): токен и uid текущего пользователя.
 * При выходе данные полностью очищаются — повторный вход требует пароль.
 */
class SessionStore(private val context: Context) {

    private val keyUid = stringPreferencesKey("uid")
    private val keyToken = stringPreferencesKey("token")
    private val keyEmail = stringPreferencesKey("email")

    val uidFlow: Flow<String?> = context.dataStore.data.map { it[keyUid] }
    val tokenFlow: Flow<String?> = context.dataStore.data.map { it[keyToken] }

    suspend fun save(uid: String, token: String?, email: String) {
        context.dataStore.edit { prefs ->
            prefs[keyUid] = uid
            if (token != null) prefs[keyToken] = token
            prefs[keyEmail] = email
        }
    }

    suspend fun token(): String? = context.dataStore.data.first()[keyToken]
    suspend fun uid(): String? = context.dataStore.data.first()[keyUid]
    suspend fun email(): String? = context.dataStore.data.first()[keyEmail]

    suspend fun clear() {
        context.dataStore.edit { it.clear() }
    }
}
