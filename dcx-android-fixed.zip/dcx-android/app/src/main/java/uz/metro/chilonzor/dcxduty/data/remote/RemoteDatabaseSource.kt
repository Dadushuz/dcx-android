package uz.metro.chilonzor.dcxduty.data.remote

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import uz.metro.chilonzor.dcxduty.data.remote.dto.LogDto
import uz.metro.chilonzor.dcxduty.data.remote.dto.MetaDto
import uz.metro.chilonzor.dcxduty.data.remote.dto.OrderDto
import uz.metro.chilonzor.dcxduty.data.remote.dto.ProfileDto
import uz.metro.chilonzor.dcxduty.data.remote.dto.TemplateDto

/**
 * Источник данных Realtime Database.
 * Работает через Firebase SDK, если он инициализирован; иначе — через REST (резервный режим).
 */
class RemoteDatabaseSource(private val context: Context) {

    private val sdkReady: Boolean get() = FirebaseApp.getApps(context).isNotEmpty()

    private fun db(): FirebaseDatabase = FirebaseDatabase.getInstance(FirebaseConfig.DATABASE_URL)

    private fun ref(path: String): DatabaseReference = db().getReference(path)

    // ================== SDK-режим ==================

    suspend fun pushOrderSdk(dto: OrderDto): Boolean = runCatching {
        ref("${FirebaseConfig.ORDERS}/${dto.id}").setValue(dto).await()
        true
    }.getOrElse { Log.w(TAG, "pushOrder: ${it.message}"); false }

    suspend fun pushLogSdk(dto: LogDto): Boolean = runCatching {
        ref("${FirebaseConfig.LOGS}/${dto.id}").setValue(dto).await()
        true
    }.getOrElse { false }

    suspend fun pushMetaSdk(dto: MetaDto): Boolean = runCatching {
        ref(FirebaseConfig.META).setValue(dto).await()
        true
    }.getOrElse { false }

    suspend fun pushProfileSdk(dto: ProfileDto): Boolean = runCatching {
        ref("${FirebaseConfig.USERS}/${dto.uid}").setValue(dto).await()
        true
    }.getOrElse { false }

    suspend fun pushTemplateSdk(dto: TemplateDto): Boolean = runCatching {
        ref("${FirebaseConfig.TEMPLATES}/${dto.id}").setValue(dto).await()
        true
    }.getOrElse { false }

    suspend fun fetchOrdersSdk(): List<OrderDto> = runCatching {
        val snap = ref(FirebaseConfig.ORDERS).get().await()
        snap.children.mapNotNull { it.getValue(OrderDto::class.java) }
    }.getOrElse { emptyList() }

    suspend fun fetchOrdersOnce(): List<OrderDto> =
        if (sdkReady) fetchOrdersSdk() else fetchOrdersRest(null)

    /** Поток приказов из RTDB в реальном времени. */
    fun observeOrders(): Flow<List<OrderDto>> = callbackFlow {
        if (!sdkReady) { close(); return@callbackFlow }
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = snapshot.children.mapNotNull { it.getValue(OrderDto::class.java) }
                trySend(list)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "observeOrders отменён: ${error.message}")
                close()
            }
        }
        ref(FirebaseConfig.ORDERS).addValueEventListener(listener)
        awaitClose { ref(FirebaseConfig.ORDERS).removeEventListener(listener) }
    }

    // ================== REST-режим (без google-services.json) ==================

    suspend fun fetchOrdersRest(token: String?): List<OrderDto> {
        val raw = RestClient.request(FirebaseConfig.restUrl(FirebaseConfig.ORDERS, token)) ?: return emptyList()
        val mapType = object : com.google.gson.reflect.TypeToken<Map<String, OrderDto>>() {}.type
        val map: Map<String, OrderDto>? = runCatching {
            com.google.gson.Gson().fromJson<Map<String, OrderDto>>(raw, mapType)
        }.getOrNull()
        return map?.values?.toList().orEmpty()
    }

    suspend fun pushOrderRest(dto: OrderDto, token: String?): Boolean {
        val url = FirebaseConfig.restUrl("${FirebaseConfig.ORDERS}/${dto.id}", token)
        return RestClient.request(url, "PUT", RestClient.toJson(dto)) != null
    }

    suspend fun pushLogRest(dto: LogDto, token: String?): Boolean {
        val url = FirebaseConfig.restUrl("${FirebaseConfig.LOGS}/${dto.id}", token)
        return RestClient.request(url, "PUT", RestClient.toJson(dto)) != null
    }

    suspend fun pushProfileRest(dto: ProfileDto, token: String?): Boolean {
        val url = FirebaseConfig.restUrl("${FirebaseConfig.USERS}/${dto.uid}", token)
        return RestClient.request(url, "PUT", RestClient.toJson(dto)) != null
    }

    suspend fun pushMetaRest(dto: MetaDto, token: String?): Boolean {
        val url = FirebaseConfig.restUrl(FirebaseConfig.META, token)
        return RestClient.request(url, "PUT", RestClient.toJson(dto)) != null
    }

    suspend fun fetchProfileRest(uid: String, token: String?): ProfileDto? {
        val raw = RestClient.request(FirebaseConfig.restUrl("${FirebaseConfig.USERS}/$uid", token)) ?: return null
        return RestClient.fromJson(raw, ProfileDto::class.java)
    }

    suspend fun fetchProfilesRest(token: String?): List<ProfileDto> {
        val raw = RestClient.request(FirebaseConfig.restUrl(FirebaseConfig.USERS, token)) ?: return emptyList()
        val type = object : com.google.gson.reflect.TypeToken<Map<String, ProfileDto>>() {}.type
        val map: Map<String, ProfileDto>? = runCatching {
            com.google.gson.Gson().fromJson<Map<String, ProfileDto>>(raw, type)
        }.getOrNull()
        return map?.values?.toList().orEmpty()
    }

    val isSdkReady: Boolean get() = sdkReady

    companion object {
        private const val TAG = "DcxRemote"
    }
}
