package uz.metro.chilonzor.dcxduty.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// ===== Фирменная палитра Чиланзарской линии =====
val MetroBlue = Color(0xFF0B3C74)
val MetroBlueDark = Color(0xFF082B54)
val MetroBlueLight = Color(0xFF1E63B0)
val MetroAccent = Color(0xFFF2B234)

// ===== Цвета статусов приказа =====
val StatusDraft = Color(0xFF6B7280)
val StatusPending = Color(0xFFD97706)
val StatusIssued = Color(0xFF1D4ED8)
val StatusJournal = Color(0xFF15803D)
val StatusCanceled = Color(0xFFB91C1C)

// ===== Опасные операции =====
val DangerRed = Color(0xFFC62828)
val DangerRedDark = Color(0xFF8E1B1B)

private val LightColors = lightColorScheme(
    primary = MetroBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4F7),
    onPrimaryContainer = MetroBlueDark,
    secondary = MetroBlueLight,
    onSecondary = Color.White,
    tertiary = MetroAccent,
    onTertiary = Color(0xFF3A2A00),
    background = Color(0xFFF6F8FB),
    onBackground = Color(0xFF11181F),
    surface = Color.White,
    onSurface = Color(0xFF11181F),
    surfaceVariant = Color(0xFFE6ECF4),
    onSurfaceVariant = Color(0xFF3C4756),
    error = DangerRed,
    onError = Color.White,
    outline = Color(0xFF9AA7B6),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FB6E8),
    onPrimary = Color(0xFF04203F),
    primaryContainer = Color(0xFF12355E),
    onPrimaryContainer = Color(0xFFD6E4F7),
    secondary = Color(0xFF9CC4F0),
    onSecondary = Color(0xFF06223F),
    tertiary = MetroAccent,
    onTertiary = Color(0xFF3A2A00),
    background = Color(0xFF101418),
    onBackground = Color(0xFFE3E8EF),
    surface = Color(0xFF171C22),
    onSurface = Color(0xFFE3E8EF),
    surfaceVariant = Color(0xFF26303B),
    onSurfaceVariant = Color(0xFFC2CBD6),
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF3A0000),
    outline = Color(0xFF6E7A88),
)

@Composable
fun DcxTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        val context = LocalContext.current
        SideEffect {
            val window = (context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = MetroBlueDark.toArgb()
            window.navigationBarColor = MetroBlueDark.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }
    MaterialTheme(
        colorScheme = colors,
        typography = DcxTypography,
        shapes = DcxShapes,
        content = content,
    )
}
