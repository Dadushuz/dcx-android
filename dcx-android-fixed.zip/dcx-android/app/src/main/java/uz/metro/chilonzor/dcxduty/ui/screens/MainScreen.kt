package uz.metro.chilonzor.dcxduty.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import uz.metro.chilonzor.dcxduty.di.AppContainer
import uz.metro.chilonzor.dcxduty.ui.components.ConfirmDialog
import uz.metro.chilonzor.dcxduty.ui.components.InfoBanner
import uz.metro.chilonzor.dcxduty.ui.components.RolePill
import uz.metro.chilonzor.dcxduty.ui.components.ToastHost
import uz.metro.chilonzor.dcxduty.ui.navigation.BOTTOM_TABS
import uz.metro.chilonzor.dcxduty.ui.navigation.Routes
import uz.metro.chilonzor.dcxduty.ui.navigation.routeTitle
import uz.metro.chilonzor.dcxduty.ui.theme.MetroBlue
import uz.metro.chilonzor.dcxduty.ui.theme.StatusJournal
import uz.metro.chilonzor.dcxduty.ui.theme.StatusPending
import uz.metro.chilonzor.dcxduty.ui.viewmodel.AdminViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.AppShellViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.CreateOrderViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.DcxViewModelFactory
import uz.metro.chilonzor.dcxduty.ui.viewmodel.DutyViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.JournalViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.LogsViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.ReportsViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.TemplatesViewModel

/**
 * Основной каркас приложения: верхняя панель (статус связи, очередь, выход),
 * нижняя навигация (5 вкладок) и NavHost с экранами.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    container: AppContainer,
    factory: DcxViewModelFactory,
    onLoggedOut: () -> Unit,
) {
    val navController = rememberNavController()
    val shellVm: AppShellViewModel = viewModel(factory = factory)
    val shell by shellVm.state.collectAsStateWithLifecycle()
    val toast by shellVm.toast.collectAsStateWithLifecycle()
    var showLogout by remember { mutableStateOf(false) }

    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: Routes.DUTY

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MetroBlue,
                        titleContentColor = Color.White,
                        actionIconContentColor = Color.White,
                    ),
                    title = {
                        Column {
                            Text(routeTitle(currentRoute),
                                style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            shell.user?.let { u ->
                                Text(u.displayName.ifBlank { u.email },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White.copy(alpha = 0.85f))
                            }
                        }
                    },
                    actions = {
                        shell.user?.let { RolePill(it.role) }
                        Spacer(Modifier.width(6.dp))
                        // Ручная синхронизация с индикатором очереди.
                        BadgedBox(badge = {
                            if (shell.pendingSync > 0) {
                                Badge(containerColor = StatusPending) { Text(shell.pendingSync.toString()) }
                            }
                        }) {
                            IconButton(onClick = { shellVm.syncNow() }) {
                                Icon(Icons.Filled.Sync, contentDescription = "Синхронизировать")
                            }
                        }
                        IconButton(onClick = { showLogout = true }) {
                            Icon(Icons.Filled.ExitToApp, contentDescription = "Выход")
                        }
                    },
                )
                if (!shell.online) {
                    InfoBanner(
                        "🔴 ОФЛАЙН — изменения сохраняются и отправятся при появлении связи" +
                            if (shell.pendingSync > 0) " (в очереди: ${shell.pendingSync})" else "",
                        StatusPending,
                    )
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 4.dp) {
                BOTTOM_TABS.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = {
                            if (currentRoute != tab.route) {
                                navController.navigate(tab.route) {
                                    popUpTo(Routes.DUTY) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, style = MaterialTheme.typography.labelMedium) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            AppNavHost(navController, factory, onLoggedOut)
        }

        // Всплывающие уведомления (успех / ошибка) поверх контента.
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.BottomCenter) {
            ToastHost(
                message = toast?.first,
                isError = toast?.second ?: false,
                modifier = Modifier.padding(16.dp),
            )
        }
    }

    LaunchedEffect(toast) {
        if (toast != null) {
            kotlinx.coroutines.delay(3_500)
            shellVm.clearToast()
        }
    }

    if (showLogout) {
        ConfirmDialog(
            title = "Выход из системы",
            text = if (shell.pendingSync > 0)
                "В очереди на синхронизацию ${shell.pendingSync} записей. Они будут отправлены при следующем подключении. Завершить сеанс?"
            else "Завершить сеанс и вернуться на экран входа?",
            confirmText = "Выйти",
            onConfirm = {
                showLogout = false
                shellVm.logout { onLoggedOut() }
            },
            onDismiss = { showLogout = false },
        )
    }
}

/** Все экраны приложения. */
@Composable
private fun AppNavHost(
    navController: NavHostController,
    factory: DcxViewModelFactory,
    onLoggedOut: () -> Unit,
) {
    NavHost(navController = navController, startDestination = Routes.DUTY) {

        composable(Routes.DUTY) {
            val vm: DutyViewModel = viewModel(factory = factory)
            DutyScreen(vm) { route -> navController.navigate(route) }
        }

        composable(Routes.JOURNAL) {
            val vm: JournalViewModel = viewModel(factory = factory)
            JournalScreen(vm)
        }

        composable(Routes.CREATE) {
            val vm: CreateOrderViewModel = viewModel(factory = factory)
            CreateOrderScreen(vm) { _ ->
                navController.navigate(Routes.JOURNAL) {
                    popUpTo(Routes.DUTY) { saveState = true }
                    launchSingleTop = true
                }
            }
        }

        composable(Routes.REPORTS) {
            val vm: ReportsViewModel = viewModel(factory = factory)
            ReportsScreen(vm)
        }

        composable(Routes.MORE) {
            MoreScreen(onNavigate = { route -> navController.navigate(route) })
        }

        composable(Routes.TEMPLATES) {
            val vm: TemplatesViewModel = viewModel(factory = factory)
            TemplatesScreen(vm) { navController.popBackStack() }
        }

        composable(Routes.LOGS) {
            val vm: LogsViewModel = viewModel(factory = factory)
            LogsScreen(vm) { navController.popBackStack() }
        }

        composable(Routes.ADMIN) {
            val vm: AdminViewModel = viewModel(factory = factory)
            AdminScreen(vm) { navController.popBackStack() }
        }
    }
}

/** Заголовок подэкрана с кнопкой «Назад» — используется во вложенных разделах. */
@Composable
fun SubScreenHeader(title: String, subtitle: String? = null, onBack: () -> Unit) {
    Surface(color = MetroBlue, shape = RoundedCornerShape(bottomStart = 0.dp, bottomEnd = 0.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack) {
                Icon(Icons.Filled.Close, null, tint = Color.White, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("Назад", color = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White,
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                subtitle?.let {
                    Text(it, color = Color.White.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
