package uz.metro.chilonzor.dcxduty.data.remote.dto

/** Ответ Identity Toolkit (вход / регистрация). */
data class AuthResponseDto(
    val localId: String? = null,
    val email: String? = null,
    val idToken: String? = null,
    val refreshToken: String? = null,
    val expiresIn: String? = null,
)

/** Обёртка ошибки Identity Toolkit. */
data class ErrorEnvelopeDto(val error: ErrorBodyDto? = null)
data class ErrorBodyDto(val code: Int? = null, val message: String? = null)

/**
 * Транспортная модель приказа для Firebase Realtime Database.
 * Обычный класс с изменяемыми полями — так десериализатор Firebase работает надёжно.
 */
class OrderDto {
    var id: String = ""
    var number: Int? = null
    var cat: String = ""
    var draft: Boolean = false
    var canceled: Boolean = false
    var utvAt: Long? = null
    var paper: Boolean = false
    var at: Long = 0L
    var upd: Long = 0L
    var time: String? = null
    var from: String? = null
    var to: String? = null
    var allSt: Boolean = false
    var targets: List<String> = emptyList()
    var shift: String = "NONE"
    var byDch: String? = null
    var accepted: String? = null
    var handed: String? = null
    var body: String = ""
    var fields: Map<String, Any?> = emptyMap()
}

/** Транспортная модель лога. */
class LogDto {
    var id: String = ""
    var at: Long = 0L
    var user: String = ""
    var action: String = ""
}

/** Транспортная модель шаблона. */
class TemplateDto {
    var id: String = ""
    var cat: String = ""
    var title: String = ""
    var text: String = ""
    var upd: Long = 0L
}

/** Транспортная модель профиля сотрудника. */
class ProfileDto {
    var uid: String = ""
    var email: String = ""
    var name: String = ""
    var role: String = "dch"
    var stationCode: String? = null
    var active: Boolean = true
}

/** Транспортная модель метаданных дежурства. */
class MetaDto {
    var activeDch: String = ""
    var prevDch: String = ""
    var next: Int = 1
    var upd: Long = 0L
}
