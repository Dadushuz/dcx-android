package uz.metro.chilonzor.dcxduty.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import uz.metro.chilonzor.dcxduty.data.repository.AuthRepositoryImpl
import uz.metro.chilonzor.dcxduty.di.AppContainer
import uz.metro.chilonzor.dcxduty.domain.model.LogEntry
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.OrderCategory
import uz.metro.chilonzor.dcxduty.domain.model.OrderStatus
import uz.metro.chilonzor.dcxduty.domain.model.OrderTemplate
import uz.metro.chilonzor.dcxduty.domain.model.ReportFilter
import uz.metro.chilonzor.dcxduty.domain.model.ReportSummary
import uz.metro.chilonzor.dcxduty.domain.model.Shift
import uz.metro.chilonzor.dcxduty.domain.model.Stations
import uz.metro.chilonzor.dcxduty.domain.model.UserProfile
import uz.metro.chilonzor.dcxduty.domain.repository.LogRepository
import uz.metro.chilonzor.dcxduty.domain.repository.OrderRepository
import uz.metro.chilonzor.dcxduty.domain.repository.TemplateRepository
import uz.metro.chilonzor.dcxduty.domain.usecase.ExportCsvUseCase
import uz.metro.chilonzor.dcxduty.domain.usecase.FilterOrdersUseCase

// ======================= ЖУРНАЛ ПРИКАЗОВ =======================

enum class JournalTab { ALL, PENDING, NOT_IN_JOURNAL, DRAFTS }

fun JournalTab.title(): String = when (this) {
    JournalTab.ALL -> "Все приказы"
    JournalTab.PENDING -> "Ожидают утверждения"
    JournalTab.NOT_IN_JOURNAL -> "Не внесены в журнал"
    JournalTab.DRAFTS -> "Заготовки"
}

data class JournalUiState(
    val tab: JournalTab = JournalTab.ALL,
    val orders: List<Order> = emptyList(),
    val search: String = "",
    val user: UserProfile? = null,
    val counts: Map<JournalTab, Int> = emptyMap(),
)

class JournalViewModel(
    private val orderRepo: OrderRepository,
    private val auth: AuthRepositoryImpl,
) : ViewModel() {

    private val tab = MutableStateFlow(JournalTab.ALL)
    private val search = MutableStateFlow("")
    private val _toast = MutableStateFlow<Pair<String, Boolean>?>(null)
    val toast: StateFlow<Pair<String, Boolean>?> = _toast.asStateFlow()

    val state: StateFlow<JournalUiState> = combine(
        tab, search, auth.currentUser, orderRepo.observeAll(),
    ) { t, q, user, all ->
        JournalUiState(
            tab = t,
            search = q,
            user = user,
            orders = all.filter { matchesTab(it, t) && matchesQuery(it, q) },
            counts = mapOf(
                JournalTab.ALL to all.size,
                JournalTab.PENDING to all.count { it.status == OrderStatus.PENDING },
                JournalTab.NOT_IN_JOURNAL to all.count { it.status == OrderStatus.ISSUED },
                JournalTab.DRAFTS to all.count { it.draft },
            ),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), JournalUiState())

    fun setTab(value: JournalTab) = tab.update { value }
    fun setSearch(value: String) = search.update { value }

    fun approve(order: Order) = viewModelScope.launch {
        val name = auth.currentSnapshot?.name.orEmpty()
        orderRepo.approve(order.id, name)
        _toast.value = "Приказ № ${order.number ?: "—"} утверждён." to false
    }

    fun markInJournal(order: Order) = viewModelScope.launch {
        orderRepo.markInPaperJournal(order.id)
        _toast.value = "Приказ № ${order.number ?: "—"} внесён в бумажный журнал." to false
    }

    fun cancel(order: Order, reason: String) = viewModelScope.launch {
        if (reason.isBlank()) {
            _toast.value = "Укажите причину отмены приказа." to true
            return@launch
        }
        orderRepo.cancel(order.id, reason)
        _toast.value = "Приказ № ${order.number ?: "—"} отменён." to false
    }

    fun clearToast() { _toast.value = null }

    private fun matchesTab(o: Order, t: JournalTab): Boolean = when (t) {
        JournalTab.ALL -> true
        JournalTab.PENDING -> o.status == OrderStatus.PENDING
        JournalTab.NOT_IN_JOURNAL -> o.status == OrderStatus.ISSUED
        JournalTab.DRAFTS -> o.draft
    }

    private fun matchesQuery(o: Order, q: String): Boolean {
        if (q.isBlank()) return true
        val needle = q.trim().lowercase()
        return (o.number?.toString()?.contains(needle) == true) ||
            o.body.lowercase().contains(needle) ||
            categoryTitle(o.category).lowercase().contains(needle) ||
            o.stationSummary().lowercase().contains(needle) ||
            (o.issuedByDch ?: "").lowercase().contains(needle)
    }
}

// ======================= ОТЧЁТЫ =======================

data class ReportsUiState(
    val filter: ReportFilter = ReportFilter(),
    val orders: List<Order> = emptyList(),
    val summary: ReportSummary = ReportSummary(),
    val employees: List<String> = emptyList(),
)

class ReportsViewModel(
    private val orderRepo: OrderRepository,
    private val auth: AuthRepositoryImpl,
) : ViewModel() {

    private val filterUseCase = FilterOrdersUseCase()
    private val csvUseCase = ExportCsvUseCase()
    private val filter = MutableStateFlow(ReportFilter())

    val state: StateFlow<ReportsUiState> = combine(
        filter, orderRepo.observeAll(), auth.currentUser,
    ) { f, all, _ ->
        val filtered = filterUseCase(all, f)
        ReportsUiState(
            filter = f,
            orders = filtered.sortedByDescending { it.createdAt },
            summary = csvUseCase.summary(filtered),
            employees = all.mapNotNull { it.issuedByDch }.filter { it.isNotBlank() }.distinct().sorted(),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ReportsUiState())

    fun setShift(shift: Shift) = filter.update { it.copy(shift = shift) }
    fun setStation(code: String?) = filter.update { it.copy(stationCode = code) }
    fun setCategory(category: OrderCategory?) = filter.update { it.copy(category = category) }
    fun setEmployee(name: String?) = filter.update { it.copy(employee = name) }
    fun setDateFrom(ts: Long?) = filter.update { it.copy(dateFrom = ts) }
    fun setDateTo(ts: Long?) = filter.update { it.copy(dateTo = ts) }
    fun resetFilter() = filter.update { ReportFilter() }

    /** CSV-содержимое по текущим фильтрам. */
    fun csvContent(): String = csvUseCase.export(state.value.orders) { categoryTitle(it) }

    /** CSV-архив всех приказов (панель основателя / журнал). */
    fun csvArchive(orders: List<Order>): String = csvUseCase.export(orders) { categoryTitle(it) }

    /** Список станций для фильтра (только реально встречающиеся). */
    fun stationOptions(): List<String> {
        val codes = state.value.orders.flatMap {
            buildList {
                it.targetStationCodes.forEach { c -> add(c) }
                it.fromStationCode?.let { c -> add(c) }
                it.toStationCode?.let { c -> add(c) }
            }
        }.distinct()
        return codes.ifEmpty { Stations.codes }
    }
}

// ======================= ШАБЛОНЫ =======================

data class TemplatesUiState(
    val templates: List<OrderTemplate> = emptyList(),
    val category: OrderCategory = OrderCategory.AB_TO_ALS,
    val title: String = "",
    val text: String = "",
)

class TemplatesViewModel(private val templateRepo: TemplateRepository) : ViewModel() {

    private val _form = MutableStateFlow(TemplatesUiState())
    private val _toast = MutableStateFlow<Pair<String, Boolean>?>(null)
    val toast: StateFlow<Pair<String, Boolean>?> = _toast.asStateFlow()

    val state: StateFlow<TemplatesUiState> = combine(
        templateRepo.observeAll(), _form,
    ) { list, form -> form.copy(templates = list) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TemplatesUiState())

    fun setCategory(c: OrderCategory) = _form.update { it.copy(category = c) }
    fun setTitle(v: String) = _form.update { it.copy(title = v) }
    fun setText(v: String) = _form.update { it.copy(text = v) }

    fun addTemplate() {
        val f = _form.value
        if (f.title.isBlank()) {
            _toast.value = "Укажите название подшаблона." to true
            return
        }
        viewModelScope.launch {
            templateRepo.save(
                OrderTemplate(
                    id = "tpl_${System.currentTimeMillis()}",
                    category = f.category,
                    title = f.title.trim(),
                    textTemplate = f.text.trim(),
                )
            )
            _form.update { it.copy(title = "", text = "") }
            _toast.value = "Подшаблон добавлен." to false
        }
    }

    fun remove(id: String) = viewModelScope.launch {
        templateRepo.remove(id)
        _toast.value = "Подшаблон удалён." to false
    }

    fun clearToast() { _toast.value = null }
}

// ======================= ЛОГИ =======================

class LogsViewModel(private val logRepo: LogRepository) : ViewModel() {

    val state: StateFlow<List<LogEntry>> = logRepo.observeRecent(300)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun clear() = viewModelScope.launch { logRepo.clear() }
}

// ======================= ПАНЕЛЬ ОСНОВАТЕЛЯ =======================

data class AdminUiState(
    val accounts: List<UserProfile> = emptyList(),
    val nextNumber: Int = 1,
    val user: UserProfile? = null,
    val email: String = "",
    val password: String = "",
    val name: String = "",
    val role: uz.metro.chilonzor.dcxduty.domain.model.Role = uz.metro.chilonzor.dcxduty.domain.model.Role.DCH,
    val stationCode: String? = null,
)

class AdminViewModel(
    private val orderRepo: OrderRepository,
    private val auth: AuthRepositoryImpl,
    private val logRepo: LogRepository,
) : ViewModel() {

    private val csvUseCase = ExportCsvUseCase()
    private val allOrders = MutableStateFlow<List<Order>>(emptyList())

    private val form = MutableStateFlow(AdminUiState())
    private val _toast = MutableStateFlow<Pair<String, Boolean>?>(null)
    val toast: StateFlow<Pair<String, Boolean>?> = _toast.asStateFlow()

    val state: StateFlow<AdminUiState> = combine(
        form, auth.currentUser,
    ) { f, user -> f.copy(user = user) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AdminUiState())

    init {
        refresh()
        viewModelScope.launch {
            orderRepo.observeAll().collect { allOrders.value = it }
        }
    }

    fun refresh() = viewModelScope.launch {
        val accounts = runCatching { auth.listAccounts() }.getOrDefault(emptyList())
        val next = runCatching { orderRepo.peekNextNumber() }.getOrDefault(1)
        form.update { it.copy(accounts = accounts, nextNumber = next) }
    }

    fun setEmail(v: String) = form.update { it.copy(email = v) }
    fun setPassword(v: String) = form.update { it.copy(password = v) }
    fun setName(v: String) = form.update { it.copy(name = v) }
    fun setRole(v: uz.metro.chilonzor.dcxduty.domain.model.Role) = form.update { it.copy(role = v) }
    fun setStation(code: String?) = form.update { it.copy(stationCode = code) }

    fun createAccount() {
        val f = form.value
        if (!f.email.contains("@")) { _toast.value = "Некорректный адрес электронной почты." to true; return }
        if (f.password.length < 6) { _toast.value = "Пароль должен содержать не менее 6 символов." to true; return }
        if (f.name.isBlank()) { _toast.value = "Укажите фамилию сотрудника." to true; return }
        if (f.role == uz.metro.chilonzor.dcxduty.domain.model.Role.STATION && f.stationCode == null) {
            _toast.value = "Выберите станцию для работника станции." to true; return
        }
        viewModelScope.launch {
            auth.createAccount(
                f.email, f.password,
                UserProfile(
                    uid = "",
                    email = f.email.trim(),
                    name = f.name.trim(),
                    role = f.role,
                    stationCode = if (f.role == uz.metro.chilonzor.dcxduty.domain.model.Role.STATION) f.stationCode else null,
                ),
            ).onSuccess {
                _toast.value = "Аккаунт создан: ${f.email}" to false
                form.update { it.copy(email = "", password = "", name = "", stationCode = null) }
                logRepo.log("Создал(а) аккаунт: ${f.email} (${f.role.label()})", auth.currentSnapshot?.name.orEmpty())
                refresh()
            }.onFailure { t ->
                _toast.value = "Не удалось создать аккаунт: ${t.message ?: "ошибка сети"}" to true
            }
        }
    }

    fun setNextNumber(value: String) {
        val n = value.toIntOrNull()
        if (n == null || n <= 0) { _toast.value = "Некорректный номер приказа." to true; return }
        viewModelScope.launch {
            orderRepo.setNextNumber(n)
            _toast.value = "Следующий номер приказа: № $n" to false
            refresh()
        }
    }

    fun cleanup() = viewModelScope.launch {
        val removed = orderRepo.cleanupApprovedOlderThan(5)
        _toast.value = "Очищено приказов старше 5 дней: $removed" to false
    }

    fun syncNow() = viewModelScope.launch {
        val sent = runCatching { orderRepo.syncNow() }.getOrElse { -1 }
        _toast.value = if (sent < 0) "Синхронизация не удалась: нет связи." to true
        else "Синхронизация выполнена: $sent записей." to false
    }

    fun clearToast() { _toast.value = null }

    /** CSV-архив всех приказов (панель основателя). */
    fun csvArchiveCsv(): String = csvUseCase.export(allOrders.value) { categoryTitle(it) }
}

private fun uz.metro.chilonzor.dcxduty.domain.model.Role.label(): String = when (this) {
    uz.metro.chilonzor.dcxduty.domain.model.Role.FOUNDER -> "ОСНОВАТЕЛЬ"
    uz.metro.chilonzor.dcxduty.domain.model.Role.CHIEF -> "СТАРШИЙ ДЦХ"
    uz.metro.chilonzor.dcxduty.domain.model.Role.DCH -> "ДЦХ"
    uz.metro.chilonzor.dcxduty.domain.model.Role.STATION -> "Работник станции"
}

// ======================= ФАБРИКА VIEWMODEL =======================

/** Создаёт все ViewModel приложения из DI-контейнера (без Hilt). */
class DcxViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val vm: ViewModel = when {
            modelClass.isAssignableFrom(LoginViewModel::class.java) ->
                LoginViewModel(container.authRepository)

            modelClass.isAssignableFrom(AppShellViewModel::class.java) ->
                AppShellViewModel(
                    container.authRepository,
                    container.orderRepository,
                    container.dutyRepository,
                    container.networkMonitor,
                )

            modelClass.isAssignableFrom(DutyViewModel::class.java) ->
                DutyViewModel(
                    container.authRepository,
                    container.orderRepository,
                    container.dutyRepository,
                    uz.metro.chilonzor.dcxduty.domain.usecase.ShiftWindowUseCase(),
                )

            modelClass.isAssignableFrom(CreateOrderViewModel::class.java) ->
                CreateOrderViewModel(
                    container.orderRepository,
                    container.templateRepository,
                    container.authRepository,
                    uz.metro.chilonzor.dcxduty.domain.usecase.ShiftWindowUseCase(),
                )

            modelClass.isAssignableFrom(JournalViewModel::class.java) ->
                JournalViewModel(container.orderRepository, container.authRepository)

            modelClass.isAssignableFrom(ReportsViewModel::class.java) ->
                ReportsViewModel(container.orderRepository, container.authRepository)

            modelClass.isAssignableFrom(TemplatesViewModel::class.java) ->
                TemplatesViewModel(container.templateRepository)

            modelClass.isAssignableFrom(LogsViewModel::class.java) ->
                LogsViewModel(container.logRepository)

            modelClass.isAssignableFrom(AdminViewModel::class.java) ->
                AdminViewModel(container.orderRepository, container.authRepository, container.logRepository)

            else -> throw IllegalArgumentException("Неизвестная ViewModel: ${modelClass.name}")
        }
        return vm as T
    }
}
