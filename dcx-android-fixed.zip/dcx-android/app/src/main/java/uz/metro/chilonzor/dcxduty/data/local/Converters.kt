package uz.metro.chilonzor.dcxduty.data.local

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/** Конвертеры Room для списков и словарей (хранятся как JSON-строки). */
class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromStringList(value: List<String>?): String = gson.toJson(value ?: emptyList<String>())

    @TypeConverter
    fun toStringList(value: String?): List<String> {
        if (value.isNullOrBlank()) return emptyList()
        val type = object : TypeToken<List<String>>() {}.type
        return runCatching { gson.fromJson<List<String>>(value, type) }.getOrDefault(emptyList())
    }

    @TypeConverter
    fun fromStringMap(value: Map<String, String>?): String = gson.toJson(value ?: emptyMap<String, String>())

    @TypeConverter
    fun toStringMap(value: String?): Map<String, String> {
        if (value.isNullOrBlank()) return emptyMap()
        val type = object : TypeToken<Map<String, String>>() {}.type
        return runCatching { gson.fromJson<Map<String, String>>(value, type) }.getOrDefault(emptyMap())
    }
}
