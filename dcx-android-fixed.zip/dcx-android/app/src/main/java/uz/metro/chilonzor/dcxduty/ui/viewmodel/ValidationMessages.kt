package uz.metro.chilonzor.dcxduty.ui.viewmodel

import uz.metro.chilonzor.dcxduty.domain.model.FieldError

/**
 * Преобразование кодов ошибок валидации в понятные русские сообщения.
 * Ключ вида "err_required:Время выдачи" превращается в "Заполните обязательное поле: Время выдачи".
 */
object ValidationMessages {

    fun resolve(error: FieldError): String = resolveKey(error.messageRes)

    fun resolveKey(key: String): String = when {
        key.startsWith("err_required:") ->
            "Заполните обязательное поле: ${key.removePrefix("err_required:")}"
        key == "err_time_format" -> "Неверный формат времени. Ожидается ЧЧ:ММ (например, 08:30)."
        key == "err_train_number" -> "Номер поезда должен содержать 3–6 цифр."
        key == "err_train_blank" -> "Укажите номер хозяйственного поезда."
        key == "err_station_same" -> "Станции отправления и назначения не должны совпадать."
        key == "err_station_required" -> "Выберите станцию из списка."
        key == "err_time_order" -> "Время выдачи раньше времени приёма дежурства."
        key == "err_track_required" -> "Выберите главный путь."
        key == "err_other_train_number" -> "Укажите номер другого хозяйственного поезда."
        else -> key
    }

    /** Карта "ключ поля -> текст ошибки" для быстрого доступа в форме. */
    fun toMap(errors: List<FieldError>): Map<String, String> =
        errors.associate { it.fieldKey to resolve(it) }
}
