package uz.metro.chilonzor.dcxduty.domain.model

/**
 * Типы приказов ДЦХ (Чиланзарская линия).
 * [code] совпадает с ключом в Firebase Realtime Database (обратная совместимость с web-версией).
 */
enum class OrderCategory(val code: String) {
    SHIFT_HANDOVER("SHIFT_HANDOVER"),
    HOZ_WRONG_DIR("HOZ_WRONG_DIR"),
    AB_TO_ALS("AB_TO_ALS"),
    ALS_TO_AB("ALS_TO_AB"),
    ENERGY_DCH("ENERGY_DCH"),
    VOLTAGE_OFF("VOLTAGE_OFF"),
    TRACK_CLOSE("TRACK_CLOSE");

    /** Опасная операция: требует двухступенчатого подтверждения. */
    val isDangerous: Boolean
        get() = this == VOLTAGE_OFF || this == TRACK_CLOSE

    companion object {
        fun fromCode(code: String?): OrderCategory? =
            entries.firstOrNull { it.code == code }

        /** Список для выпадающего списка "Раздел приказа". */
        val all: List<OrderCategory> = entries.toList()

        /** Разделы, доступные для создания заготовки шаблона. */
        val templateSections: List<OrderCategory> = listOf(
            AB_TO_ALS, ALS_TO_AB, ENERGY_DCH, VOLTAGE_OFF, TRACK_CLOSE
        )
    }
}
