package uz.metro.chilonzor.dcxduty.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.metro.chilonzor.dcxduty.domain.model.FieldKeys
import uz.metro.chilonzor.dcxduty.domain.model.OrderCategory
import uz.metro.chilonzor.dcxduty.domain.model.Stations
import uz.metro.chilonzor.dcxduty.ui.components.DangerConfirmDialog
import uz.metro.chilonzor.dcxduty.ui.components.DcxDropdown
import uz.metro.chilonzor.dcxduty.ui.components.DcxTextField
import uz.metro.chilonzor.dcxduty.ui.components.OptionChips
import uz.metro.chilonzor.dcxduty.ui.components.SectionCard
import uz.metro.chilonzor.dcxduty.ui.components.StationDropdown
import uz.metro.chilonzor.dcxduty.ui.theme.DangerRed
import uz.metro.chilonzor.dcxduty.ui.theme.MetroAccent
import uz.metro.chilonzor.dcxduty.ui.viewmodel.CreateOrderViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.categoryTitle

private const val DANGER_VOLTAGE =
    "Снятие напряжения с контактного рельса. Убедитесь, что работы согласованы с " +
        "энергодиспетчером (ЭЧЦ) и люди выведены с пути. Ошибочное снятие напряжения " +
        "создаёт угрозу жизни."

private const val DANGER_TRACK =
    "Закрытие пути (перегона) для движения всех поездов. Убедитесь, что поезда на участке " +
        "отсутствуют, а машинисты уведомлены. Ошибочное закрытие нарушает график и " +
        "безопасность движения."

/** Значения главного пути для чипов. */
private val TRACKS = listOf("I главный путь", "II главный путь")

@Composable
fun CreateOrderScreen(
    vm: CreateOrderViewModel,
    onIssued: (Int?) -> Unit,
) {
    val s by vm.state.collectAsStateWithLifecycle()
    val toast by vm.toast.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        vm.onIssued = { order -> onIssued(order.number) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // ===== Заголовок и номер =====
        item {
            Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(16.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Выдать приказ / заготовка",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Следующий номер приказа: № ${s.nextNumber}",
                            style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.85f))
                    }
                    if (s.shiftWindowOpen) {
                        Surface(color = MetroAccent, shape = RoundedCornerShape(50)) {
                            Text("ПЕРЕСМЕНКА", color = Color(0xFF3A2A00),
                                style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                    }
                }
            }
        }

        if (toast != null) {
            item {
                Surface(
                    color = if (toast!!.second) DangerRed else MaterialTheme.colorScheme.tertiary,
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Text(toast!!.first, color = if (toast!!.second) Color.White else Color(0xFF2B2000),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.fillMaxWidth().padding(12.dp))
                }
            }
        }

        // ===== Раздел приказа (7 типов) =====
        item {
            SectionCard("Раздел приказа", subtitle = "Выберите тип операции ДЦХ") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(OrderCategory.all, key = { it.code }) { cat ->
                        FilterChip(
                            selected = s.category == cat,
                            onClick = { vm.selectCategory(cat) },
                            label = { Text(categoryTitle(cat), style = MaterialTheme.typography.bodyMedium) },
                            leadingIcon = if (cat.isDangerous) {
                                { Icon(Icons.Filled.Warning, null, Modifier.size(18.dp), tint = DangerRed) }
                            } else null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = if (cat.isDangerous)
                                    DangerRed.copy(alpha = 0.15f) else MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = if (cat.isDangerous)
                                    DangerRed else MaterialTheme.colorScheme.onPrimaryContainer,
                            ),
                        )
                    }
                }
                if (s.category.isDangerous) {
                    Spacer(Modifier.height(10.dp))
                    Surface(color = DangerRed.copy(alpha = 0.10f), shape = RoundedCornerShape(10.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, null, tint = DangerRed, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(10.dp))
                            Text("ОПАСНАЯ ОПЕРАЦИЯ — потребуется двойное подтверждение",
                                color = DangerRed, style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // ===== Подшаблоны =====
        if (s.subTemplates.isNotEmpty()) {
            item {
                SectionCard("Шаблон текста", subtitle = "При выдаче подставляются путь, участок и основание") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        s.subTemplates.forEach { t ->
                            val selected = s.selectedSubTemplateId == t.id
                            Surface(
                                onClick = { vm.selectSubTemplate(t.id) },
                                color = if (selected) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(12.dp),
                                border = if (selected) androidx.compose.foundation.BorderStroke(
                                    1.5.dp, MaterialTheme.colorScheme.primary) else null,
                            ) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    if (selected) {
                                        Icon(Icons.Filled.Check, null,
                                            tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(8.dp))
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(t.title, style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = FontWeight.SemiBold)
                                        if (t.textTemplate.isNotBlank()) {
                                            Text(t.textTemplate.take(120) + if (t.textTemplate.length > 120) "…" else "",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ===== Общие реквизиты =====
        item {
            SectionCard("Реквизиты приказа") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    DcxTextField(
                        value = s.fields[FieldKeys.TIME].orEmpty(),
                        onValueChange = { vm.onField(FieldKeys.TIME, it) },
                        label = "Время выдачи (ЧЧ:ММ)",
                        required = true,
                        error = s.errors[FieldKeys.TIME],
                        placeholder = "08:30",
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StationDropdown(
                            label = "От станции",
                            selectedCode = s.fields[FieldKeys.FROM_STATION],
                            onSelect = { vm.onField(FieldKeys.FROM_STATION, it) },
                            modifier = Modifier.weight(1f),
                            error = s.errors[FieldKeys.FROM_STATION],
                        )
                        StationDropdown(
                            label = "До станции",
                            selectedCode = s.fields[FieldKeys.TO_STATION],
                            onSelect = { vm.onField(FieldKeys.TO_STATION, it) },
                            modifier = Modifier.weight(1f),
                            error = s.errors[FieldKeys.TO_STATION],
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = s.allStations, onCheckedChange = { vm.toggleAllStations(it) })
                        Spacer(Modifier.width(10.dp))
                        Text("Всем станциям", style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold)
                    }
                    if (!s.allStations) {
                        Text("Станции, которым поступит приказ:",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(Stations.list, key = { it.code }) { st ->
                                val sel = s.targetStations.contains(st.code)
                                FilterChip(
                                    selected = sel,
                                    onClick = { vm.toggleTargetStation(st.code) },
                                    label = { Text(st.full, style = MaterialTheme.typography.labelMedium) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = Color.White,
                                    ),
                                )
                            }
                        }
                        s.errors[FieldKeys.FROM_STATION]?.let {
                            Text(it, color = DangerRed, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }

        // ===== Поля по типу приказа =====
        item {
            when (s.category) {
                OrderCategory.SHIFT_HANDOVER -> ShiftHandoverFields(s, vm)
                OrderCategory.HOZ_WRONG_DIR -> HozWrongDirFields(s, vm)
                OrderCategory.AB_TO_ALS, OrderCategory.ALS_TO_AB,
                OrderCategory.ENERGY_DCH, OrderCategory.VOLTAGE_OFF,
                OrderCategory.TRACK_CLOSE -> TechFields(s, vm, s.category)
            }
        }

        // ===== Предпросмотр штампа =====
        item {
            SectionCard("Предпросмотр штампа") {
                Surface(color = Color(0xFF101418), shape = RoundedCornerShape(12.dp)) {
                    Text(
                        text = s.bodyPreview.ifBlank { "— текст сформируется после заполнения полей —" },
                        color = Color(0xFFE8EDF3),
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                    )
                }
            }
        }

        // ===== Требовать утверждение =====
        item {
            SectionCard("Маршрут согласования") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = s.requireApproval, onCheckedChange = { vm.setRequireApproval(it) })
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Требуется утверждение старшего ДЦХ",
                            style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (s.requireApproval) "Статус после выдачи: НА УТВЕРЖДЕНИИ"
                            else "Статус после выдачи: ВЫДАН (без утверждения)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        // ===== Действия =====
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { vm.saveAsTemplate() },
                    modifier = Modifier.weight(1f).height(56.dp),
                    enabled = !s.saving && s.userRoleCanIssue,
                ) {
                    Icon(Icons.Filled.Save, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("В заготовки", style = MaterialTheme.typography.labelLarge)
                }
                Button(
                    onClick = { vm.issue() },
                    modifier = Modifier.weight(1f).height(56.dp),
                    enabled = !s.saving && s.userRoleCanIssue,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (s.category.isDangerous) DangerRed else MaterialTheme.colorScheme.primary,
                    ),
                ) {
                    Icon(if (s.category.isDangerous) Icons.Filled.Warning else Icons.Filled.Check,
                        null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (s.saving) "Сохранение…" else "Выдать приказ",
                        style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        if (!s.userRoleCanIssue) {
            item {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
                    Text("Станции доступен только просмотр и приём приказов.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth().padding(12.dp))
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }

    if (s.showDangerDialog) {
        DangerConfirmDialog(
            title = categoryTitle(s.category),
            dangerText = if (s.category == OrderCategory.VOLTAGE_OFF) DANGER_VOLTAGE else DANGER_TRACK,
            actionLabel = if (s.requireApproval) "отправить на утверждение" else "выдать приказ",
            onConfirm = { vm.confirmDangerAndIssue() },
            onDismiss = { vm.closeDangerDialog() },
        )
    }
}

// ============ Поля: приём/сдача дежурства ============

@Composable
private fun ShiftHandoverFields(s: uz.metro.chilonzor.dcxduty.ui.viewmodel.CreateOrderUiState, vm: CreateOrderViewModel) {
    SectionCard("Приём и сдача дежурства") {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            DcxTextField(
                value = s.fields[FieldKeys.ACCEPTED_BY].orEmpty(),
                onValueChange = { vm.onField(FieldKeys.ACCEPTED_BY, it) },
                label = "Дежурство принял(а) ДЦХ",
                required = true,
                error = s.errors[FieldKeys.ACCEPTED_BY],
                placeholder = "Фамилия И.",
            )
            DcxTextField(
                value = s.fields[FieldKeys.HANDED_BY].orEmpty(),
                onValueChange = { vm.onField(FieldKeys.HANDED_BY, it) },
                label = "Дежурство сдал(а) ДЦХ",
                required = true,
                error = s.errors[FieldKeys.HANDED_BY],
                placeholder = "Фамилия И.",
            )
        }
    }
}

// ============ Поля: хоз. поезд в неправильном направлении ============

@Composable
private fun HozWrongDirFields(s: uz.metro.chilonzor.dcxduty.ui.viewmodel.CreateOrderUiState, vm: CreateOrderViewModel) {
    SectionCard("Хозяйственный поезд") {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            DcxTextField(
                value = s.fields[FieldKeys.HOZ_TRAIN].orEmpty(),
                onValueChange = { v -> vm.onField(FieldKeys.HOZ_TRAIN, v.filter { it.isDigit() }.take(6)) },
                label = "Хозяйственный поезд №",
                required = true,
                error = s.errors[FieldKeys.HOZ_TRAIN],
                placeholder = "3–6 цифр, например 1234",
            )
            OptionChips(
                label = "По какому главному пути",
                options = TRACKS,
                selected = s.fields[FieldKeys.HOZ_TRACK_FROM],
                optionLabel = { it },
                onSelect = { vm.onField(FieldKeys.HOZ_TRACK_FROM, it) },
                required = true,
                error = s.errors[FieldKeys.HOZ_TRACK_FROM],
            )
            OptionChips(
                label = "На какой главный путь",
                options = TRACKS,
                selected = s.fields[FieldKeys.HOZ_TRACK_TO],
                optionLabel = { it },
                onSelect = { vm.onField(FieldKeys.HOZ_TRACK_TO, it) },
                required = true,
                error = s.errors[FieldKeys.HOZ_TRACK_TO],
            )
            OptionChips(
                label = "Отправление",
                options = listOf("station", "span"),
                selected = s.fields[FieldKeys.HOZ_DEP_TYPE],
                optionLabel = { if (it == "station") "со станции" else "с перегона" },
                onSelect = { vm.onField(FieldKeys.HOZ_DEP_TYPE, it) },
                required = true,
            )
            when (s.fields[FieldKeys.HOZ_DEP_TYPE]) {
                "station" -> StationDropdown(
                    label = "Станция отправления",
                    selectedCode = s.fields[FieldKeys.HOZ_DEP_STATION],
                    onSelect = { vm.onField(FieldKeys.HOZ_DEP_STATION, it) },
                    required = true,
                    error = s.errors[FieldKeys.HOZ_DEP_STATION],
                )
                "span" -> DcxDropdown(
                    label = "Перегон отправления",
                    options = Stations.spans,
                    selected = Stations.spans.firstOrNull {
                        "${it.fromCode}-${it.toCode}" == s.fields[FieldKeys.HOZ_DEP_SPAN]
                    },
                    optionLabel = { it.name },
                    onSelect = { vm.onField(FieldKeys.HOZ_DEP_SPAN, "${it.fromCode}-${it.toCode}") },
                    required = true,
                    error = s.errors[FieldKeys.HOZ_DEP_SPAN],
                )
            }
            StationDropdown(
                label = "Станция назначения",
                selectedCode = s.fields[FieldKeys.HOZ_DEST_STATION],
                onSelect = { vm.onField(FieldKeys.HOZ_DEST_STATION, it) },
                required = true,
                error = s.errors[FieldKeys.HOZ_DEST_STATION],
            )
            OptionChips(
                label = "Граница («до / за»)",
                options = listOf("до", "за"),
                selected = s.fields["hoz-limit-mode"],
                optionLabel = { it },
                onSelect = { vm.onField("hoz-limit-mode", it) },
            )
            OptionChips(
                label = "Другой хоз. поезд",
                options = OTHERS,
                selected = s.fields["hoz-oth-mode"],
                optionLabel = { it },
                onSelect = { mode ->
                    vm.onField("hoz-oth-mode", mode)
                    if (mode == "Нет") vm.onField(FieldKeys.HOZ_OTHER_TRAIN, "")
                },
                error = s.errors[FieldKeys.HOZ_OTHER_TRAIN],
            )
            if (s.fields["hoz-oth-mode"] != null && s.fields["hoz-oth-mode"] != "Нет") {
                DcxTextField(
                    value = s.fields["hoz-oth-num"].orEmpty(),
                    onValueChange = { v ->
                        val digits = v.filter { it.isDigit() }.take(6)
                        vm.onField("hoz-oth-num", digits)
                        // В отчёт и штамп идёт и позиция ("Впереди Вас"/"За Вами"), и номер.
                        vm.onField(
                            FieldKeys.HOZ_OTHER_TRAIN,
                            "${s.fields["hoz-oth-mode"]} № $digits",
                        )
                    },
                    label = "Номер другого хоз. поезда №",
                    required = true,
                    error = s.errors[FieldKeys.HOZ_OTHER_TRAIN],
                    placeholder = "3–6 цифр",
                )
            }
        }
    }
}

/** Варианты взаимного расположения хозяйственных поездов. */
private val OTHERS = listOf("Нет", "Впереди Вас", "За Вами")

// ============ Поля: технические разделы (АБ/АЛС, ЭЧЦ, напряжение, путь) ============

@Composable
private fun TechFields(
    s: uz.metro.chilonzor.dcxduty.ui.viewmodel.CreateOrderUiState,
    vm: CreateOrderViewModel,
    category: OrderCategory,
) {
    val trackRequired = category != OrderCategory.ENERGY_DCH
    SectionCard(
        title = categoryTitle(category),
        subtitle = when (category) {
            OrderCategory.AB_TO_ALS -> "Перевод движения с автоблокировки на АЛС-АРС"
            OrderCategory.ALS_TO_AB -> "Перевод движения с АЛС-АРС на автоблокировку"
            OrderCategory.ENERGY_DCH -> "Заявка энергодиспетчеру (ЭЧЦ)"
            OrderCategory.VOLTAGE_OFF -> "Снятие/подача напряжения с контактного рельса"
            OrderCategory.TRACK_CLOSE -> "Закрытие/открытие пути (перегона)"
            else -> null
        },
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            OptionChips(
                label = "Главный путь",
                options = TRACKS + "I и II главные пути",
                selected = s.fields[FieldKeys.TECH_TRACK],
                optionLabel = { it },
                onSelect = { vm.onField(FieldKeys.TECH_TRACK, it) },
                required = trackRequired,
                error = s.errors[FieldKeys.TECH_TRACK],
            )
            DcxDropdown(
                label = "Участок / перегон",
                options = Stations.spans,
                selected = Stations.spans.firstOrNull {
                    it.name == s.fields[FieldKeys.TECH_SECTION] ||
                        "${it.fromCode} — ${it.toCode}" == s.fields[FieldKeys.TECH_SECTION]
                },
                optionLabel = { it.name },
                onSelect = { vm.onField(FieldKeys.TECH_SECTION, it.name) },
                required = true,
                error = s.errors[FieldKeys.TECH_SECTION],
            )
            if (category == OrderCategory.ENERGY_DCH) {
                DcxDropdown(
                    label = "Характер заявки ЭЧЦ",
                    options = listOf("снять напряжение", "подать напряжение"),
                    selected = s.fields["ech-mode"],
                    optionLabel = { it },
                    onSelect = { vm.onField("ech-mode", it) },
                )
            }
            DcxTextField(
                value = s.fields[FieldKeys.TECH_EXTRA].orEmpty(),
                onValueChange = { vm.onField(FieldKeys.TECH_EXTRA, it) },
                label = "Дополнительно (основание, причина, № приказа ЭЧЦ)",
                singleLine = false,
                minLines = 3,
                placeholder = "Например: заявка ЭЧЦ № 47, работы по устранению неисправности",
            )
            DcxTextField(
                value = s.fields[FieldKeys.TECH_EXTRA].orEmpty(),
                onValueChange = { vm.onField(FieldKeys.TECH_EXTRA, it) },
                label = "",
                enabled = false,
            )
        }
    }
}
