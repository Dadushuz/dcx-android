package uz.metro.chilonzor.dcxduty.data.remote

/**
 * Конфигурация Firebase.
 *
 * Приложение работает в двух режимах:
 *  1. Основной — Firebase SDK (Auth + Realtime Database). Требуется файл app/google-services.json
 *     (Firebase Console → Project settings → Your apps → Android → скачать google-services.json).
 *  2. Резервный — REST API Firebase, когда google-services.json ещё не подключён. Работает
 *     без SDK: вход, создание аккаунтов и обмен данными по HTTPS. Достаточно API-ключа ниже.
 */
object FirebaseConfig {
    /** Идентификатор проекта Firebase. */
    const val PROJECT_ID = "chilonzor-ikr"

    /** URL Realtime Database (тот же проект, что и у web-версии АРМ ДЦХ). */
    const val DATABASE_URL = "https://chilonzor-ikr-default-rtdb.asia-southeast1.firebasedatabase.app"

    /**
     * Web API key проекта (Firebase Console → Project settings → General → Web API Key).
     * Ключ клиентский и не является секретом, но в продакшене ограничьте его
     * по HTTP-referrer / Android-приложению в Google Cloud Console.
     */
    const val API_KEY = "AIzaSyDuFe4vZGsm1k5oQ-kX75FK1euluVWOxf4"

    /**
     * mobilesdk_app_id (например, "1:123456789012:android:abcdef1234567890").
     * Нужен ТОЛЬКО для ручной инициализации Firebase без google-services.json.
     * Если файл google-services.json добавлен — оставьте пустым.
     */
    const val APP_ID = ""

    // ==== Пути в Realtime Database ====
    const val ROOT = "dcx_v8"
    const val ORDERS = "$ROOT/orders"
    const val META = "$ROOT/meta"
    const val LOGS = "$ROOT/logs"
    const val TEMPLATES = "$ROOT/templates"
    const val USERS = "$ROOT/users"

    /** REST-эндпоинты Identity Toolkit (для резервного режима). */
    const val IDENTITY_BASE = "https://identitytoolkit.googleapis.com/v1"

    fun restUrl(path: String, token: String? = null): String {
        val base = "$DATABASE_URL/$path.json"
        return if (token.isNullOrBlank()) base else "$base?auth=$token"
    }
}
