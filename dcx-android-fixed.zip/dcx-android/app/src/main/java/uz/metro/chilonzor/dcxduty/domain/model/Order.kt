package uz.metro.chilonzor.dcxduty.domain.model

/**
 * Приказ ДЦХ. Модель повторяет структуру web-версии и хранится локально (Room),
 * синхронизируется с Firebase Realtime Database по мере появления сети.
 *
 * @param number      Порядковый номер приказа (null у черновика/заготовки).
 * @param draft       Черновик или заготовка (ещё не выдан).
 * @param approvedAt  Момент утверждения старшим ДЦХ (null = "НА УТВЕРЖДЕНИИ").
 * @param inPaperJournal Признак внесения в бумажный журнал.
 * @param issuedAt    Время выдачи в формате "ЧЧ:ММ".
 * @param body        Итоговый текст штампа приказа.
 * @param fields      Значения полей формы (для экспорта/повторного открытия).
 */
data class Order(
    val id: String,
    val number: Int? = null,
    val category: OrderCategory,
    val draft: Boolean = false,
    val canceled: Boolean = false,
    val approvedAt: Long? = null,
    val inPaperJournal: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val issuedAt: String? = null,
    val fromStationCode: String? = null,
    val toStationCode: String? = null,
    val allStations: Boolean = false,
    val targetStationCodes: List<String> = emptyList(),
    val shift: Shift = Shift.NONE,
    val issuedByDch: String? = null,
    val acceptedByDch: String? = null,
    val handedByDch: String? = null,
    val body: String = "",
    val fields: Map<String, String> = emptyMap(),
    val dirty: Boolean = true,
    val deleted: Boolean = false,
) {
    val status: OrderStatus get() = OrderStatus.of(this)

    /** Приказ можно редактировать только пока он не утверждён и не отменён. */
    val isEditable: Boolean
        get() = !canceled && (draft || approvedAt == null)

    /** Приказ можно отменить, если он ещё не попал в бумажный журнал. */
    val isCancelable: Boolean get() = !canceled && !inPaperJournal

    /** Человекочитаемый список станций назначения. */
    fun stationSummary(): String = when {
        allStations -> "Всем станциям"
        targetStationCodes.isNotEmpty() -> targetStationCodes.joinToString(", ") { Stations.full(it) }
        fromStationCode != null && toStationCode != null ->
            "«${Stations.full(fromStationCode)} — ${Stations.full(toStationCode)}»"
        fromStationCode != null -> Stations.full(fromStationCode)
        else -> "—"
    }
}
