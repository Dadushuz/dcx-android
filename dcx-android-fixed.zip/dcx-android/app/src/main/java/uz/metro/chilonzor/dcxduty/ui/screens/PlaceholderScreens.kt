package uz.metro.chilonzor.dcxduty.ui.screens

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.metro.chilonzor.dcxduty.domain.model.LogEntry
import uz.metro.chilonzor.dcxduty.domain.model.Order
import uz.metro.chilonzor.dcxduty.domain.model.OrderCategory
import uz.metro.chilonzor.dcxduty.domain.model.Role
import uz.metro.chilonzor.dcxduty.domain.model.Shift
import uz.metro.chilonzor.dcxduty.domain.model.Stations
import uz.metro.chilonzor.dcxduty.ui.components.DcxDropdown
import uz.metro.chilonzor.dcxduty.ui.components.DcxTextField
import uz.metro.chilonzor.dcxduty.ui.components.EmptyState
import uz.metro.chilonzor.dcxduty.ui.components.SectionCard
import uz.metro.chilonzor.dcxduty.ui.components.StationDropdown
import uz.metro.chilonzor.dcxduty.ui.components.StatusChip
import uz.metro.chilonzor.dcxduty.ui.components.ToastHost
import uz.metro.chilonzor.dcxduty.ui.fmtDateTime
import uz.metro.chilonzor.dcxduty.ui.fmtTimeSeconds
import uz.metro.chilonzor.dcxduty.ui.navigation.MORE_ENTRIES
import uz.metro.chilonzor.dcxduty.ui.theme.MetroAccent
import uz.metro.chilonzor.dcxduty.ui.theme.MetroBlue
import uz.metro.chilonzor.dcxduty.ui.theme.StatusJournal
import uz.metro.chilonzor.dcxduty.ui.theme.StatusPending
import uz.metro.chilonzor.dcxduty.ui.viewmodel.AdminViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.CsvExporter
import uz.metro.chilonzor.dcxduty.ui.viewmodel.LogsViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.ReportsViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.TemplatesViewModel
import uz.metro.chilonzor.dcxduty.ui.viewmodel.categoryTitle

// ============================== ОТЧЁТЫ ==============================

/** Отчёты: фильтры по смене/станции/типу/сотруднику + сводка + экспорт в CSV. */
@Composable
fun ReportsScreen(vm: ReportsViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var exportMessage by remember { mutableStateOf<Pair<String, Boolean>?>(null) }

    fun export() {
        runCatching {
            val content = vm.csvContent()
            val file = CsvExporter.write(context, "otchet_${CsvExporter.stamp()}.csv", content)
            val intent = CsvExporter.shareIntent(context, file)
            context.startActivity(Intent.createChooser(intent, "Экспорт отчёта (CSV)"))
            exportMessage = "CSV сохранён: ${file.name} (${s.orders.size} записей)" to false
        }.onFailure { t ->
            exportMessage = "Не удалось экспортировать: ${t.message ?: "ошибка файла"}" to true
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            SectionCard("Фильтры",
                subtitle = "Смена, станция, тип приказа, сотрудник и период") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    DcxDropdown(
                        label = "Смена",
                        options = listOf(Shift.NONE, Shift.DAY, Shift.NIGHT),
                        selected = s.filter.shift,
                        optionLabel = {
                            when (it) {
                                Shift.NONE -> "Все смены"
                                Shift.DAY -> "☀️ Дневная (08:00–20:00)"
                                Shift.NIGHT -> "🌙 Ночная (20:00–08:00)"
                            }
                        },
                        onSelect = { vm.setShift(it) },
                    )
                    StationDropdown(
                        label = "Станция",
                        selectedCode = s.filter.stationCode,
                        onSelect = { vm.setStation(it) },
                    )
                    DcxDropdown(
                        label = "Тип приказа",
                        options = listOf<OrderCategory?>(null) + OrderCategory.all,
                        selected = s.filter.category,
                        optionLabel = { if (it == null) "Все типы" else categoryTitle(it) },
                        onSelect = { vm.setCategory(it) },
                    )
                    if (s.employees.isNotEmpty()) {
                        DcxDropdown(
                            label = "Сотрудник (ДЦХ)",
                            options = listOf<String?>(null) + s.employees,
                            selected = s.filter.employee,
                            optionLabel = { it ?: "Все сотрудники" },
                            onSelect = { vm.setEmployee(it) },
                        )
                    }
                    Spacer(Modifier.height(0.dp))
                    Button(onClick = { export() }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Icon(Icons.Filled.Download, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("📥 Экспорт отчёта (CSV)", style = MaterialTheme.typography.titleMedium)
                    }
                    OutlinedButton(onClick = { vm.resetFilter() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Сбросить фильтры")
                    }
                }
            }
        }

        item {
            SectionCard("Сводка по отчёту") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ReportTile("Всего", s.summary.total, MetroBlue, Modifier.weight(1f))
                    ReportTile("На утверждении", s.summary.pending, StatusPending, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ReportTile("Выдано", s.summary.issued, MetroBlue, Modifier.weight(1f))
                    ReportTile("В журнале", s.summary.journal, StatusJournal, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                ReportTile("Отменено", s.summary.canceled, Color(0xFFB91C1C), Modifier.fillMaxWidth())
            }
        }

        item {
            Text("Приказы в отчёте (${s.orders.size})",
                style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        if (s.orders.isEmpty()) {
            item { EmptyState("По заданным фильтрам приказов не найдено.") }
        } else {
            items(s.orders, key = { it.id }) { o -> ReportOrderRow(o) }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }

    ToastHost(message = exportMessage?.first, isError = exportMessage?.second ?: false,
        modifier = Modifier.padding(16.dp))
}

@Composable
private fun ReportTile(label: String, value: Int, color: Color, modifier: Modifier = Modifier) {
    Surface(modifier, color = color.copy(alpha = 0.10f), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text("$value", style = MaterialTheme.typography.headlineSmall,
                color = color, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ReportOrderRow(order: Order) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(12.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("№ ${order.number ?: "—"}", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                StatusChip(order.status)
            }
            Text(categoryTitle(order.category), style = MaterialTheme.typography.bodyMedium)
            Text("${fmtDateTime(order.createdAt)} • ${order.stationSummary()}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ============================== ЗАГОТОВКИ (ШАБЛОНЫ) ==============================

@Composable
fun TemplatesScreen(vm: TemplatesViewModel, onBack: () -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    val toast by vm.toast.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(toast) {
        if (toast != null) { kotlinx.coroutines.delay(3_500); vm.clearToast() }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { SubScreenHeader("Заготовки приказов", "Шаблоны текстов по разделам", onBack) }

        item {
            SectionCard("Новый подшаблон",
                subtitle = "В тексте можно использовать {путь}, {участок}, {доп}") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    DcxDropdown(
                        label = "Раздел",
                        options = OrderCategory.templateSections,
                        selected = s.category,
                        optionLabel = { categoryTitle(it) },
                        onSelect = { vm.setCategory(it) },
                        required = true,
                    )
                    DcxTextField(
                        value = s.title, onValueChange = vm::setTitle,
                        label = "Название", required = true,
                        placeholder = "Например: Переход на АБ по неисправности",
                    )
                    DcxTextField(
                        value = s.text, onValueChange = vm::setText,
                        label = "Текст ({путь}, {участок}, {доп})",
                        singleLine = false, minLines = 4,
                        placeholder = "По {путь} на участке {участок} …",
                    )
                    Button(onClick = { vm.addTemplate() }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Icon(Icons.Filled.Check, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("➕ Добавить", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Существующие подшаблоны (${s.templates.size})",
                    style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }

        if (s.templates.isEmpty()) {
            item { EmptyState("Подшаблонов пока нет. Добавьте первый выше.") }
        } else {
            items(s.templates, key = { it.id }) { t ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t.title, style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.SemiBold)
                                Text(categoryTitle(t.category),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { vm.remove(t.id) }) {
                                Text("Удалить", color = Color(0xFFB91C1C))
                            }
                        }
                        if (t.textTemplate.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Surface(color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp)) {
                                Text(t.textTemplate, style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.fillMaxWidth().padding(10.dp))
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

    ToastHost(message = toast?.first, isError = toast?.second ?: false,
        modifier = Modifier.padding(16.dp))
}

// ============================== ЛОГИ ==============================

@Composable
fun LogsScreen(vm: LogsViewModel, onBack: () -> Unit) {
    val logs by vm.state.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        SubScreenHeader("Системные логи", "Хранятся последние 300 записей", onBack)
        if (logs.isEmpty()) {
            EmptyState("Записей пока нет.")
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(logs, key = { it.id }) { entry: LogEntry ->
                    Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(10.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                            Text(entry.action, style = MaterialTheme.typography.bodyMedium)
                            Text("${fmtTimeSeconds(entry.at)} • ${entry.user.ifBlank { "—" }}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

// ============================== ПАНЕЛЬ ОСНОВАТЕЛЯ ==============================

@Composable
fun AdminScreen(vm: AdminViewModel, onBack: () -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    val toast by vm.toast.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(toast) {
        if (toast != null) { kotlinx.coroutines.delay(3_500); vm.clearToast() }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { SubScreenHeader("Панель основателя", "Аккаунты, роли, нумерация, очистка", onBack) }

        if (s.user?.role != Role.FOUNDER) {
            item {
                Surface(color = MetroAccent.copy(alpha = 0.15f), shape = RoundedCornerShape(12.dp)) {
                    Text("Действие доступно только основателю.",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.fillMaxWidth().padding(14.dp))
                }
            }
        }

        if (s.user?.role == Role.FOUNDER) {

        item {
            SectionCard("Аккаунты сотрудников", subtitle = "Создание учётной записи с ролью") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    DcxTextField(s.email, vm::setEmail, "Электронная почта", required = true,
                        placeholder = "dch@chilonzor.uz")
                    DcxTextField(s.password, vm::setPassword, "Пароль (от 6 символов)", required = true,
                        placeholder = "минимум 6 символов")
                    DcxTextField(s.name, vm::setName, "Фамилия И.", required = true,
                        placeholder = "Иванов И.")
                    DcxDropdown(
                        label = "Роль",
                        options = listOf(Role.STATION, Role.DCH, Role.CHIEF, Role.FOUNDER),
                        selected = s.role,
                        optionLabel = {
                            when (it) {
                                Role.STATION -> "Работник станции"
                                Role.DCH -> "ДЦХ"
                                Role.CHIEF -> "Старший ДЦХ"
                                Role.FOUNDER -> "Основатель"
                            }
                        },
                        onSelect = { vm.setRole(it) },
                        required = true,
                    )
                    if (s.role == Role.STATION) {
                        StationDropdown(
                            label = "Станция",
                            selectedCode = s.stationCode,
                            onSelect = { vm.setStation(it) },
                            required = true,
                        )
                    }
                    Button(onClick = { vm.createAccount() },
                        modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Icon(Icons.Filled.Check, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Создать аккаунт", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }

        item {
            SectionCard("Нумерация приказов",
                subtitle = "Следующий номер: № ${s.nextNumber}") {
                var n by remember { mutableStateOf(s.nextNumber.toString()) }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    DcxTextField(n, { n = it.filter { c -> c.isDigit() }.take(4) },
                        "Следующий номер приказа №", required = true)
                    Button(onClick = { vm.setNextNumber(n) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Задать")
                    }
                }
            }
        }

        item {
            SectionCard("Обслуживание") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            runCatching {
                                val content = vm.csvArchiveCsv()
                                val file = CsvExporter.write(context, "arxiv_${CsvExporter.stamp()}.csv", content)
                                context.startActivity(Intent.createChooser(
                                    CsvExporter.shareIntent(context, file), "Архив (CSV)"))
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.Download, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("📥 Архив (CSV)")
                    }
                    OutlinedButton(onClick = { vm.syncNow() }, modifier = Modifier.fillMaxWidth()) {
                        Text("☁️ Синхронизировать")
                    }
                    OutlinedButton(onClick = { vm.cleanup() }, modifier = Modifier.fillMaxWidth()) {
                        Text("🧹 Очистить утверждённые старше 5 дней", color = Color(0xFFB91C1C))
                    }
                }
            }
        }

        item {
            SectionCard("Все аккаунты (${s.accounts.size})") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (s.accounts.isEmpty()) {
                        Text("Список пуст.", style = MaterialTheme.typography.bodyMedium)
                    } else {
                        s.accounts.forEach { acc ->
                            Surface(color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(10.dp)) {
                                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                    Text(acc.name.ifBlank { acc.email },
                                        style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                    Text("${acc.email} • ${acc.role.name}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
        } // конец блока «только для основателя»
    }

    ToastHost(message = toast?.first, isError = toast?.second ?: false,
        modifier = Modifier.padding(16.dp))
}

/** Экран «Ещё»: переходы в шаблоны, логи и панель основателя. */
@Composable
fun MoreScreen(onNavigate: (String) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Дополнительные разделы", style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold)
        }
        items(MORE_ENTRIES, key = { it.route }) { entry ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(entry.route) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(14.dp),
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = MetroBlue.copy(alpha = 0.12f), shape = RoundedCornerShape(10.dp)) {
                        Icon(entry.icon, null, tint = MetroBlue,
                            modifier = Modifier.padding(10.dp).size(22.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(entry.label, style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold)
                        Text(entry.hint, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
